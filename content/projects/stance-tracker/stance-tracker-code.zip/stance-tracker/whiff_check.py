#!/usr/bin/env python3
"""
whiff_check.py  --  when bat speed / swing xwOBA goes up after a change, do whiffs eat the gain?

For each flagged hitter, components before the flag (season to date) vs after (rest of season):
whiff per swing, K%, BB%, xwOBA on contact, overall xwOBA. Each change is compared with matched
controls (same date, same playing-time band), so the usual season-long drift in these rates
cancels. Positive = went up more than for similar hitters on the same dates.
"""

from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import evaluate as ev
import outcomes as oc

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
SEASONS = [2024, 2025, 2026]


def daily_components() -> pd.DataFrame:
    pa = oc.load_pa()
    pa["xw_bip"] = np.where(pa["bip"] == 1, pa["xw"], 0.0)
    d1 = (pa.groupby(["batter", "season", "game_date"])
            .agg(pa=("woba_denom", "sum"), k=("k", "sum"), bb=("bb", "sum"), bip=("bip", "sum"),
                 xw=("xw", "sum"), xw_bip=("xw_bip", "sum")))
    dec = pd.read_parquet(DATA / "decisions.parquet")
    d2 = dec.groupby(["batter", "season", "game_date"]).agg(sw=("swing", "sum"), wh=("whiff", "sum"))
    return d1.join(d2, how="outer").fillna(0).reset_index().sort_values(["batter", "season", "game_date"])


def split_at(daily: pd.DataFrame, keys: pd.DataFrame) -> pd.DataFrame:
    """keys: batter, season, as_of -> pre/post component rates."""
    cols = ["pa", "k", "bb", "bip", "xw", "xw_bip", "sw", "wh"]
    by = {k: v for k, v in daily.groupby(["batter", "season"])}
    rows = []
    for r in keys.drop_duplicates().itertuples(index=False):
        x = by.get((r.batter, r.season))
        if x is None:
            continue
        pre = x.loc[x["game_date"] < r.as_of, cols].sum()
        post = x.loc[x["game_date"] >= r.as_of, cols].sum()
        row = {"batter": r.batter, "season": r.season, "as_of": r.as_of}
        for lab, s in [("pre", pre), ("post", post)]:
            row[f"{lab}_whiff"] = s["wh"] / s["sw"] if s["sw"] else np.nan
            row[f"{lab}_k"] = s["k"] / s["pa"] if s["pa"] else np.nan
            row[f"{lab}_bb"] = s["bb"] / s["pa"] if s["pa"] else np.nan
            row[f"{lab}_xwcon"] = s["xw_bip"] / s["bip"] if s["bip"] else np.nan
            row[f"{lab}_xwoba"] = s["xw"] / s["pa"] if s["pa"] else np.nan
        rows.append(row)
    out = pd.DataFrame(rows)
    for m in ["whiff", "k", "bb", "xwcon", "xwoba"]:
        out["d_" + m] = out[f"post_{m}"] - out[f"pre_{m}"]
    return out


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    daily = daily_components()
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))

    fl = pd.concat([pd.read_csv(RESULTS / f"flags_{s}_scored.csv", parse_dates=["flag_date", "change_date"])
                    for s in SEASONS], ignore_index=True)
    ins = fl[fl["kind"] == "in-season"]
    conf = pd.read_csv(RESULTS / "followups_stance_swing_quality.csv", parse_dates=["flag_date", "change_date"])
    first = lambda x: x.sort_values("flag_date").drop_duplicates(["batter", "season"])
    groups = {
        "swing xwOBA up .010+ after a stance change": first(conf[conf["dq"] >= 0.010]),
        "  ...same group, bat speed up 1+ mph": first(conf[(conf["dq"] >= 0.010) &
                                                        (conf["post_bat_speed"] - conf["pre_bat_speed"] >= 1)]),
        "swing xwOBA flat after a stance change": first(conf[conf["dq"].abs() < 0.010]),
        "bat speed up 2+ mph (in-season flag)": first(ins[(ins["metric"] == "bat_speed") & (ins["delta"] > 0)]),
        "bat speed down 2+ mph (in-season flag)": first(ins[(ins["metric"] == "bat_speed") & (ins["delta"] < 0)]),
    }
    dates = {s: sorted(pd.concat([g.loc[g["season"] == s, "flag_date"] for g in groups.values()]).unique())
             for s in SEASONS}
    ctl = ev.control_pool(oc.all_snapshots(cum, prior, dates), proj)
    ctl = ctl.merge(split_at(daily, ctl[["batter", "season", "as_of"]]), on=["batter", "season", "as_of"], how="left")

    labels = {"d_whiff": "whiff/swing", "d_k": "K%", "d_bb": "BB%", "d_xwcon": "xwOBAcon", "d_xwoba": "xwOBA"}
    print("Change from before to after the flag, minus the same change for matched controls "
          "(rates in percentage points; xwOBA in points), first flag per hitter-season, 2024-26\n")
    rows = []
    for name, g in groups.items():
        g = g.copy()
        if "ros_pa" not in g:
            continue
        keys = g[["batter", "season", "flag_date"]].rename(columns={"flag_date": "as_of"})
        g = g.merge(split_at(daily, keys), left_on=["batter", "season", "flag_date"],
                    right_on=["batter", "season", "as_of"], how="left").drop(columns="as_of")
        parts = [f"{name:<44}"]
        row = {"group": name}
        for c, lab in labels.items():
            r = ev.compare(g.dropna(subset=[c]), ctl.dropna(subset=[c]), col=c, n_boot=1000)
            if not r.get("n"):
                continue
            scale = 1000 if c in ("d_xwcon", "d_xwoba") else 100
            parts.append(f"{lab} {r['diff'] * scale:+.1f} [{r['ci_lo'] * scale:+.1f},{r['ci_hi'] * scale:+.1f}]")
            row.update({f"{lab}": r["diff"], f"{lab}_lo": r["ci_lo"], f"{lab}_hi": r["ci_hi"], "hitters": r["hitters"]})
        rows.append(row)
        print(parts[0] + f"({row.get('hitters', 0)} hitters)")
        print("    " + "   ".join(parts[1:]))
    pd.DataFrame(rows).to_csv(RESULTS / "whiff_check.csv", index=False)


if __name__ == "__main__":
    main()
