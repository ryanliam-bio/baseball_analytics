#!/usr/bin/env python3
"""
tracker.py  --  weekly online changepoint tracker (live use and season replay)

At each checkpoint T, for every hitter (each side for switch hitters) and
metric, scans the games since that metric's last accepted changepoint (data
strictly before T) for the single best split. A flag is raised when BOTH

    |z| >= z[metric]          (not day-to-day noise; calibrated by null simulation)
    |delta| >= delta[metric]  (big relative to normal in-season drift, 2024-25)

Stance angle and foot separation are checked every day with a 3-game
confirmation window (median lag from change to flag: 5 days, vs 14 weekly);
swing metrics are checked on Mondays. On a flag the change date becomes the
start of a new regime, so a later reversal or second change is judged against
the new level. In the first five weeks, stance is also compared with the end of
last season (offseason changes).

Levels (thresholds.json):
  SIGNAL  the size/direction historically followed by better-than-projected hitting
  STANCE  every other significant stance change, logged so a later hot/cold stretch can be traced
  SWING   swing-metric changes (context; no outcome signal on their own)
The digest also lists hitters who just got hot or cold, with any logged change behind them.

Digest:  python tracker.py --as-of 2027-05-10
Player:  python tracker.py --as-of 2027-05-10 --player Benge
Replay:  python tracker.py --replay 2026               # whole season -> results/flags_2026.csv
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import cpd

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
RESULTS = HERE / "results"

# minimum evidence on each side of a split: (pre games, post games, post observations)
WINDOW = {**{m: (8, 5, 20) for m in cpd.STANCE_METRICS},
          **{m: (10, 7, 40) for m in cpd.SWING_METRICS},
          **{m: (10, 10, 60) for m in cpd.DECISION_METRICS},
          "xwoba": (15, 12, 50)}

THRESHOLDS_FILE = HERE / "thresholds.json"


def mondays(games: pd.DataFrame, season: int, first_after_days: int = 21) -> list[pd.Timestamp]:
    d = games.loc[games["season"] == season, "game_date"]
    start, end = d.min() + pd.Timedelta(days=first_after_days), d.max() + pd.Timedelta(days=1)
    first_mon = start + pd.Timedelta(days=(7 - start.weekday()) % 7)
    out = list(pd.date_range(first_mon, end, freq="7D"))
    if out[-1] < end:
        out.append(end)                      # final read after the last game
    return out


def daily(games: pd.DataFrame, season: int, first_after_days: int = 21) -> list[pd.Timestamp]:
    d = games.loc[games["season"] == season, "game_date"]
    return list(pd.date_range(d.min() + pd.Timedelta(days=first_after_days), d.max() + pd.Timedelta(days=1)))


def run_online(games: pd.DataFrame, season: int, metrics: list[str], noise: dict[str, cpd.Noise],
               z_thr: dict[str, float], delta_thr: dict[str, float],
               checkpoints: list[pd.Timestamp] | None = None, window: dict | None = None) -> pd.DataFrame:
    g = games[games["season"] == season].sort_values(["batter", "stand", "game_date", "game_pk"])
    checkpoints = checkpoints or mondays(games, season)
    window = {**WINDOW, **(window or {})}
    rows = []
    for (batter, stand), hg in g.groupby(["batter", "stand"], sort=False):
        dates = hg["game_date"].to_numpy()
        name = hg["player_name"].iloc[0]
        for m in metrics:
            y_all = hg[m].to_numpy(float)
            n_all = hg[cpd.n_col(m)].to_numpy(float)
            pre_g, post_g, post_n = window[m]
            regime = 0
            for T in checkpoints:
                end = int(np.searchsorted(dates, np.datetime64(T), side="left"))
                if end - regime < pre_g + post_g:
                    continue
                sp = cpd.best_split(y_all[regime:end], n_all[regime:end], noise[m], pre_g, post_g, post_n)
                if sp is None or abs(sp.z) < z_thr[m] or abs(sp.delta) < delta_thr[m]:
                    continue
                cp = regime + sp.idx
                rows.append(dict(season=season, flag_date=T, batter=batter, stand=stand, player_name=name, metric=m,
                                 change_date=pd.Timestamp(dates[cp]), regime_start=pd.Timestamp(dates[regime]),
                                 z=sp.z, delta=sp.delta, mu_pre=sp.mu_pre, mu_post=sp.mu_post,
                                 pre_games=sp.n_pre_games, post_games=sp.n_post_games,
                                 post_obs=sp.n_post_obs))
                regime = cp
    return pd.DataFrame(rows)


def null_season_max_z(games: pd.DataFrame, seasons, metric: str, noise: cpd.Noise, reps: int = 2,
                      seed: int = 0, window: tuple | None = None, checkpoint_fn=None) -> np.ndarray:
    """Season-max |z| (first regime, all checkpoints) for simulated no-change series with real game/swing counts."""
    rng = np.random.default_rng(seed)
    pre_g, post_g, post_n = window or WINDOW[metric]
    checkpoint_fn = checkpoint_fn or mondays
    out = []
    for s in seasons:
        cps = checkpoint_fn(games, s)
        g = games[(games["season"] == s)].dropna(subset=[metric])
        for _, hg in g.groupby(["batter", "stand"]):
            n = hg[cpd.n_col(metric)].to_numpy(float)
            dates = hg["game_date"].to_numpy()
            if len(n) < pre_g + post_g + 5:
                continue
            ends = np.searchsorted(dates, np.array(cps, dtype="datetime64[ns]"), side="left")
            for _ in range(reps):
                sd = np.sqrt(noise.sigma ** 2 / np.maximum(n, 1) + noise.tau ** 2)
                y = rng.normal(0, sd)
                best = 0.0
                for e in ends:
                    if e < pre_g + post_g:
                        continue
                    sp = cpd.best_split(y[:e], n[:e], noise, pre_g, post_g, post_n)
                    if sp:
                        best = max(best, abs(sp.z))
                out.append(best)
    return np.array(out)


def load_games() -> pd.DataFrame:
    return pd.read_parquet(DATA / "games.parquet")


def load_thresholds() -> dict:
    t = json.loads(THRESHOLDS_FILE.read_text())
    t["noise"] = {m: cpd.Noise(**v) for m, v in t["noise"].items()}
    return t


def level(row, t: dict) -> str:
    for r in t["signal"]:
        right_way = r["dir"] == "any" or (r["dir"] == "up") == (row["delta"] > 0)
        if row["metric"] == r["metric"] and right_way and abs(row["delta"]) >= r["delta"] and row["kind"] == "in-season":
            return "SIGNAL"
    return t["role"][row["metric"]].upper()


def run_all(games: pd.DataFrame, season: int, t: dict, through: pd.Timestamp | None = None) -> pd.DataFrame:
    """In-season scan (stance daily with a 3-game confirmation, swing metrics on Mondays) plus the
    first-weeks comparison with last season (offseason changes)."""
    import offseason
    ds = t["daily_stance"]
    fast = ds["metrics"]
    slow = [m for m in t["z"] if m not in fast]
    mon, day = mondays(games, season), daily(games, season)
    if through is not None:
        mon = [c for c in mon if c <= through] + ([through] if through not in mon else [])
        day = [c for c in day if c <= through]
    f1 = run_online(games, season, fast, t["noise"], ds["z"], t["delta"], checkpoints=day,
                    window={m: tuple(ds["window"]) for m in fast})
    f2 = run_online(games, season, slow, t["noise"], t["z"], t["delta"], checkpoints=mon)
    off = []
    if (games["season"] == season - 1).any():
        o = t["offseason"]
        for m in o["metrics"]:
            off += offseason.scan_shifted(games, season, m, t["noise"][m], o["z"][m], o["delta"][m])
    f3 = pd.DataFrame(off)
    if through is not None and len(f3):
        f3 = f3[f3["flag_date"] <= through]
    flags = pd.concat([f1.assign(kind="in-season"), f2.assign(kind="in-season"), f3.assign(kind="offseason")],
                      ignore_index=True)
    if flags.empty:
        return flags
    flags["level"] = flags.apply(level, axis=1, t=t)
    flags["unit"] = flags["metric"].map(cpd.UNITS)
    flags["label"] = flags["metric"].map(cpd.LABELS)
    return flags.sort_values(["flag_date", "level", "player_name"]).reset_index(drop=True)


def fmt_flags(x: pd.DataFrame) -> str:
    x = x.copy()
    x["shift"] = (x["mu_pre"].round(1).astype(str) + " -> " + x["mu_post"].round(1).astype(str) + " " + x["unit"]
                  + "  (" + x["delta"].map(lambda d: f"{d:+.1f}") + ")")
    for c in ["change_date", "flag_date"]:
        x[c] = pd.to_datetime(x[c]).dt.strftime("%m-%d")
    x["z"] = x["z"].round(1)
    x["kind"] = x["kind"].replace({"in-season": "", "offseason": "vs last season"})
    cols = ["level", "player_name", "stand", "label", "shift", "change_date", "flag_date", "z", "kind"]
    return x[cols].to_string(index=False)


def streak_status(T: pd.Timestamp, t: dict) -> pd.DataFrame:
    """Hitters whose last N PA before T sit .060+ above/below the projection they had when that stretch began."""
    import pickle
    import attribution as at
    import outcomes as oc
    pa, prior = oc.load_pa(), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    st = t["streak"]
    pri = prior.set_index(["batter", "season"])
    rows = []
    ps = pa[(pa["season"] == T.year) & (pa["game_date"] < T)].sort_values(["batter", "game_date", "at_bat_number"])
    for b, x in ps.groupby("batter"):
        if len(x) < st["window_pa"]:
            continue
        n, xw = x["woba_denom"].to_numpy(float), x["xw"].to_numpy(float)
        s0 = len(x) - st["window_pa"]
        ppa, pw = pri.loc[(b, T.year), ["prior_pa", "prior_woba"]] if (b, T.year) in pri.index else (np.nan, np.nan)
        p0 = float(at.project(proj, np.array([n[:s0].sum()]), np.array([xw[:s0].sum()]), ppa, pw)[0])
        last = xw[s0:].sum() / n[s0:].sum()
        if abs(last - p0) >= st["gap"]:
            rows.append(dict(batter=b, player_name=x["player_name"].iloc[0], status="HOT" if last > p0 else "COLD",
                             window_start=x["game_date"].iloc[s0], last_xwoba=last, proj_at_start=p0, gap=last - p0))
    return pd.DataFrame(rows, columns=["batter", "player_name", "status", "window_start", "last_xwoba",
                                       "proj_at_start", "gap"])


def confirm_section(games: pd.DataFrame, t: dict, flags: pd.DataFrame, T: pd.Timestamp) -> None:
    """Stance changes whose 3-week swing read came in this week: did the hitter's swing traits move toward a
    higher- or lower-xwOBA profile? "Swing xwOBA" = what bat speed, attack angle, attack direction, contact
    depth and tilt predict for xwOBA across the league. It describes the profile, it doesn't grade the swing."""
    import pickle
    import followups as fu
    c = t["confirm"]
    due = flags[(flags["kind"] == "in-season") & flags["metric"].isin(["stance_angle", "foot_sep"])].copy()
    due["read_date"] = due["change_date"] + pd.Timedelta(days=c["days"])
    due = due[(due["read_date"] > T - pd.Timedelta(days=7)) & (due["read_date"] <= T)]
    print(f"CONFIRM: stance changes from ~{c['days']} days ago -- change in swing xwOBA (what his swing traits "
          f"predict for xwOBA league-wide; UP = +{c['dq']:.3f} or more, which historically went with beating projection)")
    if due.empty:
        print("  none due this week")
        print()
        return
    mod = pickle.load(open(DATA / "swing_quality.pkl", "rb"))
    lv = fu.segment_levels(due, games[games["game_date"] < T], c["days"])
    lv = lv[(lv["post_sw"] >= c["min_post_swings"])].dropna(subset=[f"pre_{m}" for m in fu.SWING] +
                                                           [f"post_{m}" for m in fu.SWING])
    if lv.empty:
        print("  none with enough swings yet")
        print()
        return
    pre = lv[[f"pre_{m}" for m in fu.SWING]].set_axis(fu.SWING, axis=1)
    post = lv[[f"post_{m}" for m in fu.SWING]].set_axis(fu.SWING, axis=1)
    lv["dq"] = mod.predict(fu.design(post)).to_numpy() - mod.predict(fu.design(pre)).to_numpy()
    lv["verdict"] = np.where(lv["dq"] >= c["dq"], "UP", np.where(lv["dq"] <= -c["dq"], "DOWN", "flat"))
    for r in lv.sort_values("dq", ascending=False).itertuples(index=False):
        parts = ", ".join(f"{lab} {getattr(r, 'post_' + m) - getattr(r, 'pre_' + m):+.1f}"
                          for m, lab in [("bat_speed", "bat speed"), ("attack_angle", "attack angle"),
                                         ("ad_pull", "pull"), ("depth", "contact out front")])
        print(f"  {r.verdict:<6} {r.player_name:<24} {r.label} {r.delta:+.1f} {r.unit} from {r.change_date:%m-%d}: "
              f"swing xwOBA {r.dq:+.3f}  ({parts})")
    print()


def digest(games: pd.DataFrame, t: dict, T: pd.Timestamp) -> None:
    flags = run_all(games, T.year, t, through=T)
    RESULTS.mkdir(exist_ok=True)
    flags.to_csv(RESULTS / f"change_log_{T.year}.csv", index=False)
    week = flags[flags["flag_date"] > T - pd.Timedelta(days=7)]
    print(f"=== Week ending {T.date()}  (season change log: results/change_log_{T.year}.csv)")
    print()
    box = week["metric"].isin(["dist_off_plate", "depth_in_box"])
    for lvl, blurb, sel in [("SIGNAL", "changes historically followed by better-than-projected hitting",
                             week["level"] == "SIGNAL"),
                            ("STANCE", "other significant stance-angle / foot-separation changes, logged for tracing",
                             (week["level"] == "STANCE") & ~box)]:
        x = week[sel]
        print(f"{lvl}: {blurb} ({len(x)})")
        print(fmt_flags(x) if len(x) else "  none")
        print()
    bx = week[box]
    if len(bx):
        short = {"dist_off_plate": "off plate", "depth_in_box": "depth"}
        print(f"Box position moves ({len(bx)}, logged; no outcome signal on their own): " +
              ", ".join(f"{r.player_name} {short[r.metric]} {r.delta:+.1f}" for r in bx.itertuples()))
        print()
    sig = week[week["level"] == "SIGNAL"]
    if len(sig):
        import evaluate as ev
        ctx = ev.concurrent_shift(sig, games, t["noise"],
                                  [m for m in cpd.STANCE_METRICS + cpd.SWING_METRICS if m != "com_off_plate"])
        d = ctx[["player_name", "metric"] + [c for c in ctx.columns if c.startswith("d_")]].round(1)
        d.columns = [c[2:] if c.startswith("d_") else c for c in d.columns]
        print("SIGNAL context: same split, other metrics (after minus before)")
        print(d.to_string(index=False))
        print()
    print(f"SWING changes this week: {(week['level'] == 'SWING').sum()} (in the log)")
    print()

    confirm_section(games, t, flags, T)

    st = t["streak"]
    now, before = streak_status(T, t), streak_status(T - pd.Timedelta(days=7), t)
    old = set(zip(before["batter"], before["status"]))
    new = now[[(b, s) not in old for b, s in zip(now["batter"], now["status"])]]
    print(f"HOT / COLD, new this week ({len(new)}): last {st['window_pa']} PA at least {st['gap']:.3f} xwOBA "
          f"from the projection at the start of that stretch, with any stance change logged from "
          f"{st['lead_days']} days before the stretch onward")
    for r in new.sort_values(["status", "gap"], ascending=[False, False]).itertuples(index=False):
        lo = r.window_start - pd.Timedelta(days=st["lead_days"])
        tr = flags[(flags["batter"] == r.batter) & (flags["change_date"] >= lo) & (flags["level"] != "SWING")]
        trace_txt = "; ".join(
            (f"{a.label} {a.delta:+.1f} {a.unit} vs last season [{a.level}]" if a.kind == "offseason" else
             f"{a.label} {a.delta:+.1f} {a.unit} from {a.change_date:%m-%d} [{a.level}]")
            for a in tr.itertuples()) or "no stance change logged"
        print(f"  {r.status:<4} {r.player_name:<24} {r.last_xwoba:.3f} vs proj {r.proj_at_start:.3f} "
              f"(since {r.window_start:%m-%d})  <- {trace_txt}")


def player_report(games: pd.DataFrame, t: dict, name: str, T: pd.Timestamp) -> None:
    import outcomes as oc
    g = games[(games["season"] == T.year) & (games["game_date"] < T) &
              games["player_name"].str.contains(name, case=False, na=False)]
    if g.empty:
        print(f"no games for '{name}' in {T.year}")
        return
    flags = run_all(games, T.year, t, through=T)
    f = flags[flags["batter"].isin(g["batter"].unique())]
    print(f"=== {g['player_name'].iloc[0]}, {T.year} through {T.date()}")
    print()
    print("Change log:")
    print(fmt_flags(f) if len(f) else "  none")
    mets = ["stance_angle", "foot_sep", "dist_off_plate", "depth_in_box", "ad_pull", "depth", "bat_speed", "attack_angle"]
    m = g.assign(month=g["game_date"].dt.to_period("M")).groupby(["stand", "month"])[mets].mean().round(1)
    pa = oc.load_pa()
    p = pa[(pa["batter"].isin(g["batter"].unique())) & (pa["season"] == T.year) & (pa["game_date"] < T)]
    perf = p.groupby(p["game_date"].dt.to_period("M")).agg(PA=("woba_denom", "sum"), xw=("xw", "sum"))
    perf["xwOBA"] = (perf["xw"] / perf["PA"]).round(3)
    print()
    print("Monthly levels (stance from Savant; swing metrics location-adjusted):")
    print(m.to_string())
    print()
    print("Monthly xwOBA:")
    print(perf[["PA", "xwOBA"]].T.to_string())


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--as-of", help="digest for the 7 days through this date (YYYY-MM-DD)")
    p.add_argument("--player", help="change log + monthly levels for one hitter (with --as-of)")
    p.add_argument("--replay", type=int, help="replay a whole season -> results/flags_<season>.csv")
    args = p.parse_args()
    sys.stdout.reconfigure(encoding="utf-8")
    games = load_games()
    t = load_thresholds()
    RESULTS.mkdir(exist_ok=True)
    if args.replay:
        flags = run_all(games, args.replay, t)
        out = RESULTS / f"flags_{args.replay}.csv"
        flags.to_csv(out, index=False)
        print(f"{len(flags)} flags -> {out}")
        print(flags.groupby(["level", "kind"]).size().to_string())
    if args.as_of and args.player:
        player_report(games, t, args.player, pd.Timestamp(args.as_of))
    elif args.as_of:
        digest(games, t, pd.Timestamp(args.as_of))


if __name__ == "__main__":
    main()
