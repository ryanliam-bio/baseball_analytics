#!/usr/bin/env python3
"""
attribution.py  --  when a hitter gets hot or cold, does a stance change tell you it's real?

Streak: at a Monday T, the hitter's last 100 PA (this season) have an xwOBA at least .060
above (hot) or below (cold) the projection he had when that 100-PA window began.
First streak of each direction per hitter-season.

Traced: a stance flag from the replay (stance angle 12+ deg or feet 4.5+ in; known by T,
i.e. flag_date <= T) whose change date falls between 21 days before the window began and T.

Questions:
  1. How often are streaks traced, vs the same hitters at random 100-PA windows? (lift)
  2. Does a traced streak carry forward better than an untraced one? (rest-of-season
     xwOBA from T minus the projection at T; both groups are streaking, so selection is matched)

Writes results/streaks.csv, results/attribution_summary.csv
"""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np
import pandas as pd

import outcomes as oc
import tracker

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
SEASONS = [2024, 2025, 2026]
WINDOW_PA, HOT = 100, 0.060
LEAD_DAYS = 21


def project(proj, pa_n, xw_sum, prior_pa, prior_woba):
    ytd = np.where(pa_n > 0, xw_sum / np.maximum(pa_n, 1), 0.0)
    pp = np.nan_to_num(prior_pa)
    pw = np.where(np.isnan(prior_woba), proj.lg, prior_woba)
    return (pa_n * ytd + proj.b * pp * (pw + proj.c) + proj.k * proj.lg) / (pa_n + proj.b * pp + proj.k)


def find_streaks(pa: pd.DataFrame, prior: pd.DataFrame, proj, games: pd.DataFrame) -> pd.DataFrame:
    rows = []
    pri = prior.set_index(["batter", "season"])
    for s in SEASONS:
        mons = np.array(tracker.mondays(games, s), dtype="datetime64[ns]")
        ps = pa[pa["season"] == s].sort_values(["batter", "game_date", "at_bat_number"])
        for b, x in ps.groupby("batter"):
            if len(x) < WINDOW_PA + 50:
                continue
            d = x["game_date"].to_numpy()
            n = x["woba_denom"].to_numpy(float)
            xw = x["xw"].to_numpy(float)
            cn, cx = np.cumsum(n), np.cumsum(xw)
            ppa, pw = (pri.loc[(b, s), ["prior_pa", "prior_woba"]] if (b, s) in pri.index else (np.nan, np.nan))
            seen = set()
            for T in mons:
                end = int(np.searchsorted(d, T, side="left"))          # PAs strictly before T
                if end < WINDOW_PA:
                    continue
                st = end - WINDOW_PA
                win_n = cn[end - 1] - (cn[st - 1] if st > 0 else 0)
                win_x = cx[end - 1] - (cx[st - 1] if st > 0 else 0)
                before_n = cn[st - 1] if st > 0 else 0.0
                before_x = cx[st - 1] if st > 0 else 0.0
                p_start = float(project(proj, np.array([before_n]), np.array([before_x]), ppa, pw)[0])
                gap = win_x / win_n - p_start
                kind = "hot" if gap >= HOT else ("cold" if gap <= -HOT else None)
                if kind is None or kind in seen:
                    continue
                seen.add(kind)
                p_T = float(project(proj, np.array([cn[end - 1]]), np.array([cx[end - 1]]), ppa, pw)[0])
                ros_n, ros_x = cn[-1] - cn[end - 1], cx[-1] - cx[end - 1]
                rows.append(dict(batter=b, season=s, kind=kind, T=pd.Timestamp(T), window_start=pd.Timestamp(d[st]),
                                 window_xwoba=win_x / win_n, proj_at_start=p_start, gap=gap, proj_at_T=p_T,
                                 ros_pa=ros_n, ros_xwoba=ros_x / ros_n if ros_n else np.nan,
                                 player_name=x["player_name"].iloc[0]))
    return pd.DataFrame(rows)


def trace(st: pd.DataFrame, flags: pd.DataFrame, lead_days: int = LEAD_DAYS, shift_days: int = 0,
          bounds: dict | None = None) -> pd.Series:
    """True if a qualifying flag known by T has a change date in [window_start - lead, T] (optionally shifted).
    Shifted windows that leave the part of the season where flags can fire are NaN."""
    out = []
    by = {k: v for k, v in flags.groupby(["batter", "season"])}
    for r in st.itertuples(index=False):
        T = r.T + pd.Timedelta(days=shift_days)
        lo = r.window_start + pd.Timedelta(days=shift_days - lead_days)
        if bounds and (lo < bounds[r.season][0] or T > bounds[r.season][1]):
            out.append(np.nan)
            continue
        f = by.get((r.batter, r.season))
        if f is None:
            out.append(False)
            continue
        hit = ((f["flag_date"] <= T) & (f["change_date"] >= lo) & (f["change_date"] <= T)).any()
        out.append(bool(hit))
    return pd.Series(out, index=st.index)


def same_window_rate(st: pd.DataFrame, flags: pd.DataFrame, pa: pd.DataFrame) -> pd.Series:
    cnt = pa.sort_values("game_date").groupby(["batter", "season"])
    first100 = cnt.apply(lambda x: x["game_date"].iloc[WINDOW_PA - 1] if len(x) >= WINDOW_PA else pd.NaT,
                         include_groups=False).rename("d100").reset_index()
    out = []
    for r in st.itertuples(index=False):
        elig = first100[(first100["season"] == r.season) & (first100["d100"] < r.T) & (first100["batter"] != r.batter)]
        lo = r.window_start - pd.Timedelta(days=LEAD_DAYS)
        f = flags[(flags["season"] == r.season) & (flags["flag_date"] <= r.T) &
                  (flags["change_date"] >= lo) & (flags["change_date"] <= r.T)]
        out.append(elig["batter"].isin(f["batter"]).mean() if len(elig) else np.nan)
    return pd.Series(out, index=st.index)


def main() -> None:
    games = tracker.load_games()
    pa = oc.load_pa()
    prior = oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    flags = pd.concat([pd.read_csv(RESULTS / f"flags_{s}.csv", parse_dates=["flag_date", "change_date"])
                       for s in SEASONS], ignore_index=True)
    stance = flags[flags["metric"].isin(["stance_angle", "foot_sep"])]
    signal = stance[((stance["metric"] == "foot_sep") & (stance["delta"] < 0)) |
                    ((stance["metric"] == "stance_angle") & (stance["delta"] <= -15))]
    swing = flags[flags["metric"].isin(["ad_pull", "depth", "attack_angle", "bat_speed"])]

    st = find_streaks(pa, prior, proj, games)
    # flags can only fire ~2 weeks in (8 pre-games + 3 post); shifted windows must stay inside that
    bounds = {y: (games.loc[games["season"] == y, "game_date"].min() + pd.Timedelta(days=14),
                  games.loc[games["season"] == y, "game_date"].max()) for y in SEASONS}
    st["resid"] = st["ros_xwoba"] - st["proj_at_T"]
    for name, f in [("stance", stance), ("signal", signal), ("swing", swing)]:
        st["traced_" + name] = trace(st, f)
        # chance rate: share of OTHER hitters with 100+ PA by T who had a qualifying flag in the
        # same calendar window (controls for flags clustering early in the season)
        st["chance_" + name] = same_window_rate(st, f, pa)
    st.to_csv(RESULTS / "streaks.csv", index=False)

    rows = []
    for kind in ["hot", "cold"]:
        x = st[(st["kind"] == kind) & (st["ros_pa"] >= 75)]
        for name in ["stance", "signal", "swing"]:
            t = x["traced_" + name]
            r = dict(kind=kind, flag=name, streaks=len(x), traced_share=t.mean(),
                     chance_share=x["chance_" + name].mean(skipna=True))
            r["lift"] = r["traced_share"] / r["chance_share"] if r["chance_share"] else np.nan
            for lab, sel in [("traced", t), ("untraced", ~t)]:
                y = x[sel]
                r[f"n_{lab}"] = len(y)
                r[f"carry_{lab}"] = np.average(y["resid"], weights=y["ros_pa"]) if len(y) else np.nan
            # bootstrap the traced - untraced difference
            rng = np.random.default_rng(0)
            a, b = x[t], x[~t]
            diffs = []
            for _ in range(2000):
                ia, ib = rng.integers(0, len(a), len(a)), rng.integers(0, len(b), len(b))
                if len(a) and len(b):
                    diffs.append(np.average(a["resid"].to_numpy()[ia], weights=a["ros_pa"].to_numpy()[ia]) -
                                 np.average(b["resid"].to_numpy()[ib], weights=b["ros_pa"].to_numpy()[ib]))
            r["carry_diff"] = r["carry_traced"] - r["carry_untraced"]
            r["ci_lo"], r["ci_hi"] = (np.percentile(diffs, [2.5, 97.5]) if diffs else (np.nan, np.nan))
            r["window_gap"] = np.average(x["gap"], weights=x["ros_pa"])
            rows.append(r)
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "attribution_summary.csv", index=False)
    pd.set_option("display.width", 220)
    print(out.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
