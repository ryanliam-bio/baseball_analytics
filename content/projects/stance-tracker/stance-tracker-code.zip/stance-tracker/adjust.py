#!/usr/bin/env python3
"""
adjust.py  --  location / pitch / park adjustment of swing metrics

For each metric y, fits y_ij = h_i + f(X_ij) + e within hitter-season (h_i is
the hitter-season level, f is league-wide), where X is what the hitter does not
control: pitch location (inside/outside, height in his zone), pitch type,
velocity, movement, count, platoon side, ballpark and batter side.
Contact depth is deliberately NOT in X: moving the contact point is part of the
changes we want to catch. `ad_at_depth` is the one exception -- it is attack
direction with contact depth also held fixed, i.e. how pulled the bat is
pointing for a given contact point.

Adjusted value = y - f(X) + mean(f), so adjusted and raw share a league average.

Out-of-sample by construction: each season is adjusted with a model trained
only on other seasons (the target season for the in-season sim, 2026, uses
2024-25 only; in live use, every prior season).

Output: data/swings_adj.parquet
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"

BASE_FEATURES = ["inside_in", "z_rel", "plate_z", "release_speed", "api_break_x_batter_in",
                 "api_break_z_with_gravity", "balls", "strikes", "same_side", "stand_r",
                 "pgroup_c", "park_c"]
CATEGORICAL = ["pgroup_c", "park_c"]
METRICS = {
    # name: (column, extra features)
    "ad_pull": ("ad_pull", []),
    "depth": ("int_y", []),
    "ad_at_depth": ("ad_pull", ["int_y"]),
    "com_off_plate": ("com_off_plate", []),
    "bat_speed": ("bat_speed", []),
    "attack_angle": ("attack_angle", []),
    "tilt": ("swing_path_tilt", []),
}
CLIP = {"ad_pull": (-60, 60), "attack_angle": (-35, 45), "swing_path_tilt": (5, 60)}


def prep(sw: pd.DataFrame) -> pd.DataFrame:
    sw = sw.copy()
    sw["ad_pull"] = -sw["attack_direction"]           # Savant: negative = pull; flip so + = pull
    for c, (lo, hi) in CLIP.items():
        sw.loc[~sw[c].between(lo, hi), c] = np.nan
    sw["stand_r"] = (sw["stand"] == "R").astype(np.int8)
    sw["pgroup_c"] = sw["pgroup"].map({"FB": 0, "BR": 1, "OS": 2}).astype(np.int8)
    parks = sorted(sw["home_team"].dropna().unique())
    sw["park_c"] = sw["home_team"].map({p: i for i, p in enumerate(parks)}).astype(np.int16)
    sw["hs"] = sw["batter"].astype(str) + "_" + sw["season"].astype(str)
    return sw


def fit_within(train: pd.DataFrame, ycol: str, feats: list[str], iters: int = 2):
    """Alternate between hitter-season means and the league-wide f(X)."""
    d = train.dropna(subset=[ycol] + feats)
    y = d[ycol].to_numpy(dtype=float)
    h = d.groupby("hs")[ycol].transform("mean").to_numpy()
    cat_mask = [f in CATEGORICAL for f in feats]
    model = None
    for _ in range(iters):
        model = HistGradientBoostingRegressor(max_iter=250, learning_rate=0.08, max_leaf_nodes=48,
                                              min_samples_leaf=200, categorical_features=cat_mask,
                                              random_state=0)
        model.fit(d[feats], y - h)
        f = model.predict(d[feats])
        h = pd.Series(y - f, index=d.index).groupby(d["hs"]).transform("mean").to_numpy()
    f = model.predict(d[feats])
    return model, float(f.mean())


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--target-seasons", type=int, nargs="+", default=[2024, 2025, 2026])
    args = p.parse_args()

    sw = prep(pd.read_parquet(DATA / "swings.parquet"))
    seasons = sorted(sw["season"].unique())
    out = sw[["season", "game_date", "game_pk", "home_team", "at_bat_number", "pitch_number", "batter",
              "player_name", "stand", "pgroup", "inside_in", "z_rel", "contact", "in_play",
              "launch_speed", "launch_angle", "spray_pull", "estimated_woba_using_speedangle"]].copy()
    r2_rows = []
    for name, (ycol, extra) in METRICS.items():
        feats = BASE_FEATURES + extra
        out[name + "_raw"] = sw[ycol]
        out[name] = np.nan
        for target in args.target_seasons:
            if target == max(seasons):
                train_seasons = [s for s in seasons if s < target]   # strictly prior data for the sim season
            else:
                train_seasons = [s for s in seasons if s not in (target, max(seasons))]  # cross-fit history
            tr = sw[sw["season"].isin(train_seasons)]
            model, fbar = fit_within(tr, ycol, feats)
            m = (sw["season"] == target) & sw[feats + [ycol]].notna().all(axis=1)
            f = model.predict(sw.loc[m, feats])
            out.loc[m, name] = sw.loc[m, ycol] - f + fbar
            # share of within-hitter variance explained, out of sample
            dev = sw.loc[m, ycol] - sw.loc[m].groupby("hs")[ycol].transform("mean")
            fdev = f - pd.Series(f, index=dev.index).groupby(sw.loc[m, "hs"]).transform("mean")
            r2 = 1 - np.var(dev - fdev) / np.var(dev)
            r2_rows.append((name, target, train_seasons, round(r2, 3)))
            print(f"{name:<14} {target}  trained on {train_seasons}  within-hitter R2 (oos) = {r2:.3f}", flush=True)
    out.to_parquet(DATA / "swings_adj.parquet", index=False)
    pd.DataFrame(r2_rows, columns=["metric", "season", "trained_on", "within_r2"]).to_csv(
        DATA / "adjust_r2.csv", index=False)
    print("wrote data/swings_adj.parquet")


if __name__ == "__main__":
    main()
