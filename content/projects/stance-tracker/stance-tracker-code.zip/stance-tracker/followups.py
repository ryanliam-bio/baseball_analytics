#!/usr/bin/env python3
"""
followups.py  --  why does narrowing work, and what made Benge's change work?

1. Swing-quality model: hitter-season xwOBA on swing-metric levels (bat speed, attack angle,
   attack direction, contact depth, tilt; quadratic so there can be a sweet spot), fit on
   2024-25, checked on 2026. Each stance change gets the model's value for the swing before
   the change and for the three weeks after it. Outcomes are measured from when that three-week
   read is known (the "confirmation" date), vs projection and matched controls.
2. Narrowing: where it starts and ends relative to the hitter's own last season, what else moves
   with it (hindsight, change -> +30 days), and whether bat speed accounts for the effect.

Writes results/followups_*.csv
"""

from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

import evaluate as ev
import outcomes as oc
import tracker

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
SEASONS = [2024, 2025, 2026]
SWING = ["bat_speed", "attack_angle", "ad_pull", "depth", "tilt"]
CONFIRM_DAYS = 21


def wmean(x: pd.DataFrame, m: str) -> float:
    y = x.dropna(subset=[m])
    return float(np.average(y[m], weights=y["n_sw"])) if len(y) and y["n_sw"].sum() > 0 else np.nan


def design(df: pd.DataFrame) -> pd.DataFrame:
    X = df[SWING].copy()
    for m in ["attack_angle", "ad_pull", "depth"]:
        X[m + "2"] = df[m] ** 2
    X["bs_x_aa"] = df["bat_speed"] * df["attack_angle"]
    return sm.add_constant(X, has_constant="add")


def fit_quality(g: pd.DataFrame, pa: pd.DataFrame):
    lv = (g.groupby(["batter", "season"])
           .apply(lambda x: pd.Series({m: wmean(x, m) for m in SWING} | {"n_sw": x["n_sw"].sum()}), include_groups=False)
           .reset_index())
    perf = pa.groupby(["batter", "season"]).agg(PA=("woba_denom", "sum"), xw=("xw", "sum")).reset_index()
    perf["xwoba"] = perf["xw"] / perf["PA"]
    d = lv.merge(perf, on=["batter", "season"])
    d = d[(d["n_sw"] >= 300) & (d["PA"] >= 250)].dropna()
    tr, te = d[d["season"] < 2026], d[d["season"] == 2026]
    mod = sm.WLS(tr["xwoba"], design(tr), weights=tr["PA"]).fit()
    pred_te = mod.predict(design(te))
    r2_in = mod.rsquared
    r2_out = 1 - np.average((te["xwoba"] - pred_te) ** 2, weights=te["PA"]) / np.average(
        (te["xwoba"] - np.average(te["xwoba"], weights=te["PA"])) ** 2, weights=te["PA"])
    d["swing_xwoba"] = mod.predict(design(d))
    return mod, d, r2_in, r2_out


def segment_levels(fl: pd.DataFrame, g: pd.DataFrame, post_days: int) -> pd.DataFrame:
    by = {k: v for k, v in g.groupby(["batter", "stand", "season"])}
    rows = []
    for r in fl.itertuples(index=False):
        hg = by[(r.batter, r.stand, r.season)]
        pre = hg[(hg["game_date"] >= r.regime_start) & (hg["game_date"] < r.change_date)]
        post = hg[(hg["game_date"] >= r.change_date) &
                  (hg["game_date"] < r.change_date + pd.Timedelta(days=post_days))]
        row = {"pre_sw": pre["n_sw"].sum(), "post_sw": post["n_sw"].sum()}
        for m in SWING:
            row["pre_" + m], row["post_" + m] = wmean(pre, m), wmean(post, m)
        rows.append(row)
    return pd.concat([fl.reset_index(drop=True), pd.DataFrame(rows)], axis=1)


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    pd.set_option("display.width", 220)
    g = tracker.load_games()
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))

    # ---------------------------------------------------------------- 1. swing quality
    mod, lv, r2_in, r2_out = fit_quality(g, pa)
    pickle.dump(mod, open(DATA / "swing_quality.pkl", "wb"))      # used by the digest's CONFIRM step
    print(f"swing-quality model: R2 {r2_in:.2f} (2024-25 fit), {r2_out:.2f} (2026 out of sample)")
    print(mod.params.round(5).to_string())
    lv.to_csv(RESULTS / "followups_swing_quality_levels.csv", index=False)

    fl = pd.concat([pd.read_csv(RESULTS / f"flags_{s}.csv", parse_dates=["flag_date", "change_date", "regime_start"])
                    for s in SEASONS], ignore_index=True)
    st = fl[(fl["kind"] == "in-season") & fl["metric"].isin(["stance_angle", "foot_sep"])].copy()
    st = segment_levels(st, g, CONFIRM_DAYS)
    st = st[(st["pre_sw"] >= 60) & (st["post_sw"] >= 40)].dropna(subset=[f"pre_{m}" for m in SWING] + [f"post_{m}" for m in SWING])
    pre = st[[f"pre_{m}" for m in SWING]].set_axis(SWING, axis=1)
    post = st[[f"post_{m}" for m in SWING]].set_axis(SWING, axis=1)
    st["q_pre"] = mod.predict(design(pre)).to_numpy()
    st["q_post"] = mod.predict(design(post)).to_numpy()
    st["dq"] = st["q_post"] - st["q_pre"]
    ref = lv[lv["season"] < 2026]["swing_xwoba"]
    st["q_pre_pct"] = st["q_pre"].apply(lambda v: (ref < v).mean() * 100)
    st["confirm_date"] = np.maximum(st["flag_date"], st["change_date"] + pd.Timedelta(days=CONFIRM_DAYS))

    conf = st.copy()
    conf["flag_date"] = conf["confirm_date"]
    conf = ev.attach_outcomes(conf.drop(columns=[c for c in conf.columns if c.startswith(("ytd_", "ros_"))] +
                                        ["proj", "resid", "resid_woba"], errors="ignore"), cum, prior, proj)
    days = {s: sorted(conf.loc[conf["season"] == s, "flag_date"].unique()) for s in SEASONS}
    ctl = ev.control_pool(oc.all_snapshots(cum, prior, days), proj)
    conf.to_csv(RESULTS / "followups_stance_swing_quality.csv", index=False)

    def show(label, x):
        r = ev.compare(x.sort_values("flag_date").drop_duplicates(["batter", "season", "metric"]), ctl)
        if r.get("n"):
            print(f"  {label:<52} {r['hitters']:>3} hitters  {r['diff']:+.3f} [{r['ci_lo']:+.3f},{r['ci_hi']:+.3f}]  "
                  f"beat .025+: {r['share_good']:.0%} (ctl {r['control_share_good']:.0%})  short: {r['share_bad']:.0%}")
        return r

    print(f"\nstance changes with a 3-week swing read: {len(conf)} flags; dq quantiles "
          f"{np.round(conf['dq'].quantile([.1, .25, .5, .75, .9]).values, 3)}")
    print("Rest of season from the 3-week read, vs projection and matched controls (first per hitter-season-metric):")
    rows = []
    for lab, sel in [("swing quality up .010+", conf["dq"] >= 0.010),
                     ("swing quality roughly flat", conf["dq"].abs() < 0.010),
                     ("swing quality down .010+", conf["dq"] <= -0.010),
                     ("started bottom-20% swing, quality up .010+", (conf["q_pre_pct"] <= 20) & (conf["dq"] >= 0.010)),
                     ("started above bottom-20%, quality up .010+", (conf["q_pre_pct"] > 20) & (conf["dq"] >= 0.010))]:
        for seas_lab, ss in [("2024-26", conf["season"] > 0), ("  2024-25", conf["season"] < 2026), ("  2026", conf["season"] == 2026)]:
            r = show(f"{lab} [{seas_lab.strip()}]", conf[sel & ss])
            rows.append(dict(group=lab, seasons=seas_lab.strip(), **r))
    # dose-response: regression of resid on dq (hitter-clustered), with controls for pre quality
    c = conf.dropna(subset=["resid"])
    c = c[c["ros_pa"] >= 75]
    X = sm.add_constant(c[["dq", "q_pre"]])
    m = sm.WLS(c["resid"], X, weights=c["ros_pa"]).fit(cov_type="cluster", cov_kwds={"groups": c["batter"]})
    print(f"\nresid ~ dq + q_pre: dq coef {m.params['dq']:+.3f} (se {m.bse['dq']:.3f}, p {m.pvalues['dq']:.3f}); "
          f"q_pre coef {m.params['q_pre']:+.3f} (p {m.pvalues['q_pre']:.3f})")
    pd.DataFrame(rows).to_csv(RESULTS / "followups_swing_quality_groups.csv", index=False)

    b = conf[(conf["batter"] == 701807) & (conf["season"] == 2026)]
    print("\nBenge:", b[["metric", "change_date", "q_pre", "q_pre_pct", "q_post", "dq"]].round(3).to_string(index=False))

    # ---------------------------------------------------------------- 2. narrowing
    nar = conf[(conf["metric"] == "foot_sep")].copy()
    last = (g.groupby(["batter", "stand", "season"])["foot_sep"].mean().rename("prior_width").reset_index()
              .assign(season=lambda d: d["season"] + 1))
    nar = nar.merge(last, on=["batter", "stand", "season"], how="left")
    nar["toward_last_season"] = (nar["mu_post"] - nar["prior_width"]).abs() < (nar["mu_pre"] - nar["prior_width"]).abs()
    league_w = g.groupby(["batter", "stand", "season"])["foot_sep"].mean()
    nar["pre_width_pct"] = nar["mu_pre"].apply(lambda v: (league_w < v).mean() * 100)
    print("\nFoot separation changes, split (outcomes from the 3-week read):")
    for lab, sel in [("narrowed", nar["delta"] < 0), ("widened", nar["delta"] > 0)]:
        x = nar[sel]
        has_prior = x["prior_width"].notna()
        print(f" {lab}: {len(x)} flags; back toward last season's width: {x.loc[has_prior, 'toward_last_season'].mean():.0%} "
              f"of {has_prior.sum()} with a prior season; median starting width pct {x['pre_width_pct'].median():.0f}")
        show(f"{lab}, back toward last season", x[has_prior & x["toward_last_season"]])
        show(f"{lab}, new territory", x[has_prior & ~x["toward_last_season"]])
        show(f"{lab}, from a wide stance (top half)", x[x["pre_width_pct"] >= 50])
        show(f"{lab}, from a narrow stance (bottom half)", x[x["pre_width_pct"] < 50])
        show(f"{lab}, swing quality up .010+", x[x["dq"] >= 0.010])
        show(f"{lab}, swing quality not up", x[x["dq"] < 0.010])

    # what moves with narrowing (hindsight: 30 days after the change)
    t = tracker.load_thresholds()
    all_st = fl[(fl["kind"] == "in-season") & fl["metric"].isin(["foot_sep", "stance_angle"])].copy()
    all_st["post_end"] = all_st["change_date"] + pd.Timedelta(days=30)
    sh = ev.concurrent_shift(all_st, g, t["noise"], SWING + ["stance_angle", "foot_sep", "chase", "z_swing"],
                             post_end_col="post_end")
    grp = np.select([(sh["metric"] == "foot_sep") & (sh["delta"] < 0), (sh["metric"] == "foot_sep") & (sh["delta"] > 0),
                     (sh["metric"] == "stance_angle") & (sh["delta"] < 0), (sh["metric"] == "stance_angle") & (sh["delta"] > 0)],
                    ["feet narrowed", "feet widened", "opened", "closed"], default="other")
    cols = [f"d_{m}" for m in SWING + ["stance_angle", "foot_sep", "chase", "z_swing"]]
    tab = sh.assign(group=grp).groupby("group")[cols].mean().round(2)
    tab.columns = [c[2:] for c in tab.columns]
    print("\nAverage shift over the 30 days after the change (after minus before):")
    print(tab.to_string())
    tab.to_csv(RESULTS / "followups_what_moves.csv")

    # mediation: does the 3-week bat speed change account for the narrowing effect?
    c = conf[(conf["ros_pa"] >= 75)].dropna(subset=["resid"]).copy()
    c["narrowed"] = ((c["metric"] == "foot_sep") & (c["delta"] < 0)).astype(float)
    c["d_bs"] = c["post_bat_speed"] - c["pre_bat_speed"]
    for spec in [["narrowed"], ["narrowed", "d_bs"], ["narrowed", "dq"]]:
        m = sm.WLS(c["resid"], sm.add_constant(c[spec]), weights=c["ros_pa"]).fit(cov_type="cluster",
                                                                                   cov_kwds={"groups": c["batter"]})
        print("  resid ~ " + " + ".join(spec) + ": " +
              ", ".join(f"{k} {m.params[k]:+.4f} (p {m.pvalues[k]:.3f})" for k in spec))


if __name__ == "__main__":
    main()
