"""
outcomes.py  --  season-to-date / rest-of-season performance and a projection baseline

The question for every flag is "did this hitter beat what we would already
have expected?", not "did he get better than his pre-change line?" (hitters
often change things while slumping, so raw before/after comparisons are
inflated by regression to the mean).

Projection as of date T (fit on 2024-25 only):

    proj = (PA_ytd * xwOBA_ytd + b * PA_prior * (wOBA_prior + c) + k * lg) /
           (PA_ytd + b * PA_prior + k)

wOBA_prior is FanGraphs wOBA from the previous season; c puts it on the
xwOBA scale. Residual = rest-of-season xwOBA - proj.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"


def load_pa() -> pd.DataFrame:
    pa = pd.read_parquet(DATA / "pa.parquet")
    pa["xw"] = pa["xwoba"] * pa["woba_denom"]
    pa["w"] = pa["woba_value"] * pa["woba_denom"]
    return pa


def load_prior() -> pd.DataFrame:
    """Previous-season PA and wOBA. FanGraphs (fg_woba_hist.csv) where available, otherwise
    computed from our own PA table, so a new season works without another export."""
    fg = pd.read_csv(DATA / "fg_woba_hist.csv")
    fg = fg.rename(columns={"year": "prior_year", "PA": "prior_pa", "wOBA": "prior_woba"})
    fg["season"] = fg["prior_year"] + 1
    fg = fg[["batter", "season", "prior_pa", "prior_woba"]]
    pa = pd.read_parquet(DATA / "pa.parquet", columns=["batter", "season", "woba_value", "woba_denom"])
    own = (pa.assign(w=pa["woba_value"] * pa["woba_denom"]).groupby(["batter", "season"])
             .agg(prior_pa=("woba_denom", "sum"), w=("w", "sum")).reset_index())
    own["prior_woba"] = own["w"] / own["prior_pa"]
    own["season"] = own["season"] + 1
    own = own[~own["season"].isin(fg["season"].unique())]
    return pd.concat([fg, own[["batter", "season", "prior_pa", "prior_woba"]]], ignore_index=True)


def daily_cum(pa: pd.DataFrame) -> pd.DataFrame:
    """Per hitter-season-date totals, plus season totals, for fast ytd/ros slicing."""
    d = (pa.groupby(["batter", "season", "game_date"])
           .agg(pa=("woba_denom", "sum"), xw=("xw", "sum"), w=("w", "sum"), k=("k", "sum"),
                bb=("bb", "sum"), bip=("bip", "sum"), brl=("barrel_proxy", "sum"))
           .reset_index().sort_values(["batter", "season", "game_date"]))
    for c in ["pa", "xw", "w", "k", "bb", "bip", "brl"]:
        d["c_" + c] = d.groupby(["batter", "season"])[c].cumsum()
        d["t_" + c] = d.groupby(["batter", "season"])[c].transform("sum")
    return d


def snapshot(cum: pd.DataFrame, as_of: pd.Timestamp, season: int) -> pd.DataFrame:
    """Season-to-date (games before as_of) and rest-of-season (games on/after as_of) lines."""
    d = cum[cum["season"] == season]
    before = d[d["game_date"] < as_of].groupby("batter").last()
    tot = d.groupby("batter").last()
    out = pd.DataFrame(index=tot.index)
    for c in ["pa", "xw", "w", "k", "bb", "bip", "brl"]:
        ytd = before["c_" + c].reindex(out.index).fillna(0)
        out["ytd_" + c] = ytd
        out["ros_" + c] = tot["t_" + c] - ytd
    for pre in ["ytd", "ros"]:
        n = out[pre + "_pa"].where(out[pre + "_pa"] > 0)
        out[pre + "_xwoba"] = out[pre + "_xw"] / n
        out[pre + "_woba"] = out[pre + "_w"] / n
        out[pre + "_k_pct"] = out[pre + "_k"] / n
        out[pre + "_bb_pct"] = out[pre + "_bb"] / n
        out[pre + "_brl_bip"] = out[pre + "_brl"] / out[pre + "_bip"].where(out[pre + "_bip"] > 0)
    out["season"] = season
    out["as_of"] = as_of
    return out.reset_index()


class Projection:
    def __init__(self, b: float = 0.5, k: float = 200.0, c: float = 0.0, lg: float = 0.315):
        self.b, self.k, self.c, self.lg = b, k, c, lg

    def predict(self, snap: pd.DataFrame) -> np.ndarray:
        pp = snap["prior_pa"].fillna(0).to_numpy()
        pw = snap["prior_woba"].fillna(self.lg).to_numpy()
        num = snap["ytd_pa"] * snap["ytd_xwoba"].fillna(0) + self.b * pp * (pw + self.c) + self.k * self.lg
        den = snap["ytd_pa"] + self.b * pp + self.k
        return (num / den).to_numpy()

    @classmethod
    def fit(cls, snaps: pd.DataFrame) -> "Projection":
        s = snaps[(snaps["ros_pa"] >= 50)].copy()
        lg = float((s["ytd_xw"].sum() + s["ros_xw"].sum()) / (s["ytd_pa"].sum() + s["ros_pa"].sum()))
        pr = s[s["prior_pa"].notna()]
        c = float(lg - np.average(pr["prior_woba"], weights=pr["prior_pa"]))
        best = None
        for b in [0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0]:
            for k in [50, 100, 150, 200, 300, 400, 600]:
                p = cls(b, k, c, lg)
                err = np.average((s["ros_xwoba"] - p.predict(s)) ** 2, weights=s["ros_pa"])
                if best is None or err < best[0]:
                    best = (err, p)
        return best[1]

    def __repr__(self) -> str:
        return f"Projection(b={self.b}, k={self.k}, c={self.c:+.3f}, lg={self.lg:.3f})"


def all_snapshots(cum: pd.DataFrame, prior: pd.DataFrame, checkpoints: dict[int, list]) -> pd.DataFrame:
    frames = [snapshot(cum, pd.Timestamp(t), s) for s, ts in checkpoints.items() for t in ts]
    snaps = pd.concat(frames, ignore_index=True)
    return snaps.merge(prior, on=["batter", "season"], how="left")
