#!/usr/bin/env python3
"""
study_stance.py  --  2024-25 stance changes: how many, how big, do they stick,
does the swing follow, and do the hitters beat projection afterwards?

Needs results/flags_hist_nodelta.parquet from analysis.py (stage 1).
Writes results/stance_study_*.csv and prints the tables.
"""

from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

import cpd
import evaluate as ev

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
SWING = ["ad_pull", "depth", "ad_at_depth", "bat_speed", "attack_angle", "tilt", "com_off_plate", "chase", "z_swing"]
BINS = {"stance_angle": [0, 5, 8, 12, 99], "foot_sep": [0, 2, 3, 4.5, 99],
        "dist_off_plate": [0, 1, 1.5, 2.5, 99], "depth_in_box": [0, 1.5, 2.5, 4, 99]}


def load():
    cal = json.load(open(RESULTS / "calibration_stage1.json"))
    noise = {m: cpd.Noise(**v) for m, v in cal["noise"].items()}
    g = pd.read_parquet(DATA / "games.parquet")
    fl = pd.read_parquet(RESULTS / "flags_hist_nodelta.parquet")
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    snaps = pd.read_parquet(DATA / "snapshots.parquet")
    ctl = ev.control_pool(snaps[snaps["season"] < 2026], proj)
    return cal, noise, g, fl, ctl


def add_context(st: pd.DataFrame, all_flags: pd.DataFrame) -> pd.DataFrame:
    st = st.copy()
    st["absd"] = st["delta"].abs()
    # earlier stance flags for the same hitter-side this season (any stance metric)
    sf = all_flags[all_flags["metric"].isin(cpd.STANCE_METRICS)]
    prior_cnt = []
    for r in st.itertuples(index=False):
        x = sf[(sf["batter"] == r.batter) & (sf["stand"] == r.stand) & (sf["season"] == r.season)
               & (sf["flag_date"] < r.flag_date)]
        prior_cnt.append(len(x))
    st["prior_stance_flags"] = prior_cnt
    st["ytd_vs_proj"] = st["ytd_xwoba"] - st["proj"]
    return st


def table(groups: dict[str, pd.DataFrame], ctl: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for name, x in groups.items():
        r = ev.compare(x, ctl)
        r["group"] = name
        r["retained_med"] = x["retained"].median() if len(x) else np.nan
        r["held_share"] = (x["retained"] >= 0.5).mean() if len(x) else np.nan
        rows.append(r)
    cols = ["group", "n", "diff", "ci_lo", "ci_hi", "share_good", "control_share_good", "share_bad",
            "retained_med", "held_share"]
    return pd.DataFrame(rows).reindex(columns=cols)


def main() -> None:
    cal, noise, g, fl, ctl = load()
    n_reg = (g[g["season"] < 2026].groupby(["batter", "stand", "season"])["n_sw"].sum() >= 300).sum()
    st = fl[fl["metric"].isin(cpd.STANCE_METRICS)].copy()
    st = ev.concurrent_shift(st, g, noise, SWING + cpd.STANCE_METRICS)
    st = add_context(st, fl)
    st.to_parquet(RESULTS / "stance_flags_hist.parquet", index=False)

    print(f"regular hitter-sides (300+ swings): {n_reg}")
    print("\n== frequency and size (z threshold only)")
    freq = st.groupby("metric").agg(flags=("z", "size"), hitters=("batter", "nunique"),
                                     med=("absd", "median"), p75=("absd", lambda s: s.quantile(.75)),
                                     p90=("absd", lambda s: s.quantile(.9)))
    freq["per_regular_season"] = freq["flags"] / n_reg
    print(freq.round(2).to_string())
    for m, b in BINS.items():
        x = st[st["metric"] == m]
        print(f"   {m}: counts by |delta| bin", pd.cut(x["absd"], b).value_counts().sort_index().to_dict())

    print("\n== does the swing move with the stance? (same split; slope of swing shift on stance shift)")
    rel = []
    for m in ["stance_angle", "foot_sep", "dist_off_plate", "depth_in_box"]:
        x = st[st["metric"] == m]
        for s in ["ad_pull", "depth", "ad_at_depth", "attack_angle", "bat_speed", "tilt", "com_off_plate"]:
            y = x.dropna(subset=["d_" + s])
            slope = np.polyfit(y["delta"], y["d_" + s], 1)[0] if len(y) > 10 else np.nan
            rel.append(dict(stance=m, swing=s, n=len(y), corr=y["delta"].corr(y["d_" + s]), slope=slope,
                            share_sig=(y["z_" + s].abs() >= 2.5).mean()))
    rel = pd.DataFrame(rel)
    print(rel.round(3).to_string(index=False))
    rel.to_csv(RESULTS / "stance_study_swing_link.csv", index=False)

    print("\n== rest-of-season xwOBA vs projection (diff vs controls on the same Mondays)")
    groups = {}
    for m in cpd.STANCE_METRICS:
        x = st[st["metric"] == m]
        groups[f"{m}: all"] = x
        for lo, hi in zip(BINS[m][:-1], BINS[m][1:]):
            groups[f"{m}: |d| {lo}-{hi}"] = x[(x["absd"] >= lo) & (x["absd"] < hi)]
        groups[f"{m}: up"] = x[x["delta"] > 0]
        groups[f"{m}: down"] = x[x["delta"] < 0]
    sa = st[st["metric"] == "stance_angle"]
    swing_sig = (sa[["z_ad_pull", "z_depth", "z_attack_angle", "z_bat_speed"]].abs() >= 2.5).any(axis=1)
    groups["angle: swing moved too (|z|>=2.5 in AD/depth/AA/bat speed)"] = sa[swing_sig]
    groups["angle: swing did not move"] = sa[~swing_sig]
    groups["angle: held (retained>=.5, hindsight)"] = sa[sa["retained"] >= 0.5]
    groups["angle: reverted (hindsight)"] = sa[sa["retained"] < 0.5]
    groups["angle: struggling before (ytd < proj - .015)"] = sa[sa["ytd_vs_proj"] < -0.015]
    groups["angle: not struggling"] = sa[sa["ytd_vs_proj"] >= -0.015]
    groups["angle: first stance flag of season"] = sa[sa["prior_stance_flags"] == 0]
    groups["angle: tinkerer (2+ earlier stance flags)"] = sa[sa["prior_stance_flags"] >= 2]
    any_st = st.sort_values("flag_date").drop_duplicates(["batter", "stand", "season", "flag_date"])
    groups["any stance flag (one per hitter-week)"] = any_st
    tab = table(groups, ctl)
    print(tab.round(3).to_string(index=False))
    tab.to_csv(RESULTS / "stance_study_outcomes.csv", index=False)


if __name__ == "__main__":
    main()
