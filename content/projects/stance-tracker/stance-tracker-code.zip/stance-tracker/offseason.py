#!/usr/bin/env python3
"""
offseason.py  --  stance changes made over the winter, caught in the first weeks of the season

Baseline: the hitter's last 30 games (same side) of the previous season. Each day for the first
35 days, compare everything so far this season (5+ games) with that baseline; flag the first day
|z| >= z_off and |delta| >= the in-season size threshold. z_off comes from a no-change null
with the same daily looks. Evaluated on 2025 and 2026 (2024 has no prior season here).

Writes results/offseason_flags.csv and prints outcome tables.
"""

from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

import cpd
import evaluate as ev
import outcomes as oc
import tracker

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
METRICS = ["stance_angle", "foot_sep"]
BASE_GAMES, MIN_GAMES, DAYS = 30, 5, 35


def series(g: pd.DataFrame, m: str):
    nc = cpd.n_col(m)
    x = g.dropna(subset=[m])
    x = x[x[nc] > 0]
    return {k: v for k, v in x.groupby(["batter", "stand", "season"])}, nc


def scan(g: pd.DataFrame, season: int, m: str, noise: cpd.Noise, z_thr: float, d_thr: float,
         sim: np.random.Generator | None = None) -> list[dict]:
    by, nc = series(g, m)
    start = g.loc[g["season"] == season, "game_date"].min()
    days = pd.date_range(start + pd.Timedelta(days=MIN_GAMES), start + pd.Timedelta(days=DAYS))
    out = []
    for (b, sd, s), cur in by.items():
        if s != season or (b, sd, s - 1) not in by:
            continue
        base = by[(b, sd, s - 1)].tail(BASE_GAMES)
        if len(base) < 15:
            continue
        wb = 1 / (noise.sigma ** 2 / base[nc] + noise.tau ** 2)
        yb = base[m].to_numpy(float)
        yc_all = cur[m].to_numpy(float)
        if sim is not None:   # null: both segments drawn around the same level
            yb = sim.normal(0, np.sqrt(1 / wb.to_numpy()))
            wc_all = 1 / (noise.sigma ** 2 / cur[nc].to_numpy(float) + noise.tau ** 2)
            yc_all = sim.normal(0, np.sqrt(1 / wc_all))
        mu_b, w_b = np.average(yb, weights=wb), wb.sum()
        dates = cur["game_date"].to_numpy()
        best = 0.0
        for T in days:
            k = int(np.searchsorted(dates, np.datetime64(T), side="left"))
            if k < MIN_GAMES:
                continue
            c = cur.iloc[:k]
            wc = 1 / (noise.sigma ** 2 / c[nc] + noise.tau ** 2)
            mu_c = np.average(yc_all[:k], weights=wc)
            z = (mu_c - mu_b) / np.sqrt(1 / w_b + 1 / wc.sum())
            best = max(best, abs(z))
            if sim is None and abs(z) >= z_thr and abs(mu_c - mu_b) >= d_thr:
                out.append(dict(season=season, batter=b, stand=sd, player_name=cur["player_name"].iloc[0], metric=m,
                                flag_date=T, change_date=cur["game_date"].iloc[0], regime_start=cur["game_date"].iloc[0],
                                mu_pre=mu_b, mu_post=mu_c, delta=mu_c - mu_b, z=z, post_games=k))
                break
        if sim is not None:
            out.append({"max_z": best})
    return out


EXTENDED = ["stance_angle", "foot_sep", "dist_off_plate", "depth_in_box",
            "bat_speed", "attack_angle", "ad_pull", "depth", "tilt"]


def scan_shifted(g: pd.DataFrame, season: int, m: str, noise: cpd.Noise, z_thr: float, d_thr: float,
                 sim: np.random.Generator | None = None) -> list[dict]:
    """Like scan(), but each day's comparison is net of the league-wide median change on that day
    (computed only from games before that day), so a measurement or model shift between seasons
    can't flag everyone at once. Works for stance and swing metrics."""
    by, nc = series(g, m)
    start = g.loc[g["season"] == season, "game_date"].min()
    days = pd.date_range(start + pd.Timedelta(days=MIN_GAMES), start + pd.Timedelta(days=DAYS))
    T64 = np.array(days, dtype="datetime64[ns]")
    recs = []
    for (b, sd, s), cur in by.items():
        if s != season or (b, sd, s - 1) not in by:
            continue
        base = by[(b, sd, s - 1)].tail(BASE_GAMES)
        if len(base) < 15:
            continue
        wb = (1 / (noise.sigma ** 2 / base[nc] + noise.tau ** 2)).to_numpy()
        wc = (1 / (noise.sigma ** 2 / cur[nc] + noise.tau ** 2)).to_numpy()
        yb, yc = base[m].to_numpy(float), cur[m].to_numpy(float)
        if sim is not None:
            yb, yc = sim.normal(0, np.sqrt(1 / wb)), sim.normal(0, np.sqrt(1 / wc))
        k = np.searchsorted(cur["game_date"].to_numpy(), T64, side="left")
        cw, cwy = np.cumsum(wc), np.cumsum(wc * yc)
        mu_c = np.where(k >= MIN_GAMES, cwy[np.maximum(k, 1) - 1] / cw[np.maximum(k, 1) - 1], np.nan)
        recs.append(dict(batter=b, stand=sd, name=cur["player_name"].iloc[0], first=cur["game_date"].iloc[0],
                         mu_b=np.average(yb, weights=wb), W_b=wb.sum(), k=k, W_c=cw[np.maximum(k, 1) - 1], mu_c=mu_c))
    if not recs:
        return []
    D = np.vstack([r["mu_c"] - r["mu_b"] for r in recs])
    if sim is not None:
        shift = np.zeros(len(days))
    else:
        with np.errstate(all="ignore"):
            shift = np.array([np.median(c[~np.isnan(c)]) if (~np.isnan(c)).any() else 0.0 for c in D.T])
    out = []
    for r, drow in zip(recs, D):
        dd = drow - shift
        z = dd / np.sqrt(1 / r["W_b"] + 1 / r["W_c"])
        if sim is not None:
            out.append({"max_z": float(np.nanmax(np.abs(z))) if np.isfinite(z).any() else 0.0})
            continue
        hit = np.flatnonzero((np.abs(z) >= z_thr) & (np.abs(dd) >= d_thr))
        if len(hit):
            j = hit[0]
            out.append(dict(season=season, batter=r["batter"], stand=r["stand"], player_name=r["name"], metric=m,
                            flag_date=days[j], change_date=r["first"], regime_start=r["first"],
                            mu_pre=r["mu_b"], mu_post=r["mu_c"][j] - shift[j], delta=dd[j], z=z[j],
                            league_shift=shift[j], post_games=int(r["k"][j])))
    return out


def main_extended() -> None:
    """Offseason check over stance AND swing metrics; calibrate, run 2025-26, score."""
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    t = tracker.load_thresholds()
    g = tracker.load_games()
    z_off = {}
    for m in EXTENDED:
        null = pd.DataFrame(scan_shifted(g, 2025, m, t["noise"][m], 0, 0, sim=np.random.default_rng(2)))
        z_off[m] = float(np.round(np.quantile(null["max_z"], 0.99), 2))
    print("offseason z (99% of no-change hitters):", z_off)
    rows = []
    for s in [2025, 2026]:
        for m in EXTENDED:
            rows += scan_shifted(g, s, m, t["noise"][m], z_off[m], t["delta"][m])
    fl = pd.DataFrame(rows)
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    fl = ev.attach_outcomes(fl, cum, prior, proj)
    fl.to_csv(RESULTS / "offseason_ext_flags.csv", index=False)
    json.dump(z_off, open(RESULTS / "z_offseason_ext.json", "w"), indent=1)
    ctl = ev.control_pool(oc.all_snapshots(cum, prior, {s: sorted(fl.loc[fl.season == s, "flag_date"].unique())
                                                         for s in [2025, 2026]}), proj)
    print(f"\n{len(fl)} flags, {fl[['batter', 'season']].drop_duplicates().shape[0]} hitter-seasons; "
          f"median flag date {fl.groupby('season')['flag_date'].median().dt.strftime('%m-%d').to_dict()}")
    print("\nRest of season from the flag date vs projection and matched controls (first per hitter-season):")
    for m in EXTENDED:
        for lab, sel in [("up", fl["delta"] > 0), ("down", fl["delta"] < 0)]:
            x = fl[(fl["metric"] == m) & sel]
            r = ev.compare(x.sort_values("flag_date").drop_duplicates(["batter", "season"]), ctl)
            if r.get("n"):
                print(f"  {m:<15} {lab:<5} {r['hitters']:>3} hitters  {r['diff']:+.3f} [{r['ci_lo']:+.3f},{r['ci_hi']:+.3f}]  "
                      f"beat .025+: {r['share_good']:.0%} (ctl {r['control_share_good']:.0%})  short: {r['share_bad']:.0%}")
    anyf = fl.sort_values("flag_date").drop_duplicates(["batter", "season"])
    r = ev.compare(anyf, ctl)
    print(f"  {'any':<21} {r['hitters']:>3} hitters  {r['diff']:+.3f} [{r['ci_lo']:+.3f},{r['ci_hi']:+.3f}]  "
          f"beat .025+: {r['share_good']:.0%} (ctl {r['control_share_good']:.0%})")
    cs = fl[fl["batter"] == 701358]
    print("\nCam Smith:")
    print(cs[["season", "metric", "flag_date", "mu_pre", "mu_post", "delta", "z", "proj", "ros_xwoba", "resid"]]
          .round(3).to_string(index=False) if len(cs) else "  not flagged")


def main() -> None:
    t = tracker.load_thresholds()
    g = tracker.load_games()
    z_off = {}
    for m in METRICS:
        null = pd.DataFrame(scan(g, 2025, m, t["noise"][m], 0, 0, sim=np.random.default_rng(1)))
        z_off[m] = float(np.round(np.quantile(null["max_z"], 0.99), 2))
    print("offseason z (99% of no-change hitters):", z_off)
    rows = []
    for s in [2025, 2026]:
        for m in METRICS:
            rows += scan(g, s, m, t["noise"][m], z_off[m], t["delta"][m])
    fl = pd.DataFrame(rows)
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    fl = ev.attach_outcomes(fl, cum, prior, proj)
    fl.to_csv(RESULTS / "offseason_flags.csv", index=False)
    json.dump(z_off, open(RESULTS / "z_offseason.json", "w"))
    ctl = ev.control_pool(oc.all_snapshots(cum, prior, {s: sorted(fl.loc[fl.season == s, "flag_date"].unique())
                                                         for s in [2025, 2026]}), proj)
    elig = sum(len([k for k in series(g, "stance_angle")[0] if k[2] == s and (k[0], k[1], s - 1) in series(g, "stance_angle")[0]])
               for s in [2025, 2026])
    print(f"{len(fl)} offseason flags across 2025-26 ({elig} hitter-sides with both seasons); "
          f"median flag date {fl['flag_date'].median().date() if len(fl) else None}")
    groups = {"feet narrowed 4.5+": fl[(fl.metric == "foot_sep") & (fl.delta < 0)],
              "feet widened 4.5+": fl[(fl.metric == "foot_sep") & (fl.delta > 0)],
              "opened 12+": fl[(fl.metric == "stance_angle") & (fl.delta < 0)],
              "closed 12+": fl[(fl.metric == "stance_angle") & (fl.delta > 0)],
              "any": fl}
    for k, x in groups.items():
        r = ev.compare(x, ctl)
        if r.get("n"):
            print(f"  {k:<20} {r['n']:>3} flags/{r['hitters']:>3} hitters  {r['diff']:+.3f} [{r['ci_lo']:+.3f},{r['ci_hi']:+.3f}]  "
                  f"beat .025+: {r['share_good']:.0%} (ctl {r['control_share_good']:.0%})  short: {r['share_bad']:.0%}")
    show = fl.sort_values("flag_date")[["season", "player_name", "metric", "flag_date", "mu_pre", "mu_post", "delta",
                                        "proj", "ros_xwoba", "resid"]]
    print(show.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
