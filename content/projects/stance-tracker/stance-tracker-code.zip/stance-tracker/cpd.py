"""
cpd.py  --  game-level series + online changepoint scan

Every metric is reduced to one value per hitter-game (swing metrics: mean of
the adjusted swings; stance metrics: Savant's per-day value), with a weight
from a two-level noise model:

    var(game mean) = sigma^2 / n_swings + tau^2

sigma = swing-to-swing noise within a game, tau = game-to-game noise that does
not persist (estimated from adjacent-game differences, so slow drift and real
changes are NOT counted as noise).

The scan, run as of any date T, looks only at games after the hitter's last
accepted changepoint for that metric, tries every split, and reports the split
with the largest |z| = |mean_after - mean_before| / SE. Thresholds are applied
in tracker.py.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"

SWING_METRICS = ["ad_pull", "depth", "ad_at_depth", "com_off_plate", "bat_speed", "attack_angle", "tilt"]
STANCE_METRICS = ["stance_angle", "foot_sep", "dist_off_plate", "depth_in_box"]
DECISION_METRICS = ["chase", "z_swing"]
PERF_METRICS = ["xwoba"]
UNITS = {"ad_pull": "deg", "depth": "in", "ad_at_depth": "deg", "com_off_plate": "in", "bat_speed": "mph",
         "attack_angle": "deg", "tilt": "deg", "stance_angle": "deg", "foot_sep": "in",
         "dist_off_plate": "in", "depth_in_box": "in", "chase": "pp", "z_swing": "pp", "xwoba": ""}
LABELS = {"ad_pull": "attack direction (+pull)", "depth": "contact depth (+out front)",
          "ad_at_depth": "attack dir. at fixed depth", "com_off_plate": "CoM off plate at contact",
          "bat_speed": "bat speed", "attack_angle": "attack angle", "tilt": "swing path tilt",
          "stance_angle": "stance angle (+closed)", "foot_sep": "foot separation",
          "dist_off_plate": "distance off plate", "depth_in_box": "depth in box",
          "chase": "chase rate", "z_swing": "zone swing rate", "xwoba": "xwOBA (performance)"}


# --------------------------------------------------------------------------- stance

def park_effects(d: pd.DataFrame, metric: str, iters: int = 6) -> pd.Series:
    """Park x batter-side offsets, estimated within hitter-season."""
    x = d.dropna(subset=[metric])
    hs = x["batter"].astype(str) + "_" + x["season"].astype(str)
    h = x.groupby(hs)[metric].transform("mean")
    for _ in range(iters):
        pe = (x[metric] - h).groupby([x["park"], x["stand"]]).transform("mean")
        h = (x[metric] - pe).groupby(hs).transform("mean")
    return (x[metric] - h).groupby([x["park"], x["stand"]]).mean()


def adjust_stance(hist_seasons=(2024, 2025)) -> pd.DataFrame:
    """Savant per-day stance with park x side offsets removed (out of sample for the newest season)."""
    st = pd.read_parquet(DATA / "stance_daily.parquet")
    sw = pd.read_parquet(DATA / "swings.parquet", columns=["batter", "game_date", "home_team"])
    day = sw.groupby(["batter", "game_date"]).agg(park=("home_team", "first")).reset_index()
    # switch hitters get one Savant row per side; bat_side is the side that row describes
    d = st.rename(columns={"bat_side": "stand"}).merge(day, on=["batter", "game_date"], how="inner")
    newest = d["season"].max()
    for m in STANCE_METRICS:
        for target in sorted(d["season"].unique()):
            train = [s for s in hist_seasons if s != newest] if target == newest else list(hist_seasons)
            pe = park_effects(d[d["season"].isin(train)], m)
            sel = d["season"] == target
            idx = pd.MultiIndex.from_arrays([d.loc[sel, "park"], d.loc[sel, "stand"]])
            d.loc[sel, m] = d.loc[sel, m] - pe.reindex(idx).fillna(0).to_numpy()
    d.to_parquet(DATA / "stance_adj.parquet", index=False)
    return d


# --------------------------------------------------------------------------- game table

def season_day(d: pd.Series) -> pd.Series:
    """Days since that season's first game."""
    first = d.groupby(d.dt.year).transform("min")
    return (d - first).dt.days


def trend_curve(df: pd.DataFrame, metric: str, seasons) -> pd.Series:
    """League-wide within-hitter seasonal trend by week of season (smoothed)."""
    d = df[df["season"].isin(seasons)].dropna(subset=[metric])
    dev = d[metric] - d.groupby(["batter", "season"])[metric].transform("mean")
    wk = (season_day(d["game_date"]) // 7).clip(upper=27)
    curve = dev.groupby(wk).mean()
    curve = curve.reindex(range(28)).interpolate().bfill().ffill()
    return curve.rolling(3, center=True, min_periods=1).mean()


def build_game_table(seasons_hist=(2024, 2025)) -> pd.DataFrame:
    """One row per hitter-game with every metric's game mean and n."""
    a = pd.read_parquet(DATA / "swings_adj.parquet")
    a["sday"] = season_day(a["game_date"])
    a["wk"] = (a["sday"] // 7).clip(upper=27)
    # de-trend: prior-season curve for the newest season, pooled history otherwise
    newest = a["season"].max()
    for m in SWING_METRICS:
        hist = [s for s in seasons_hist if s < newest]
        c_hist = trend_curve(a, m, hist)
        a[m] = a[m] - a["wk"].map(c_hist)
    g = (a.groupby(["batter", "stand", "season", "game_date", "game_pk"], observed=True)
           .agg(player_name=("player_name", "first"),
                home_team=("home_team", "first"), n_sw=("bat_speed", "size"),
                **{m: (m, "mean") for m in SWING_METRICS})
           .reset_index())

    dec = pd.read_parquet(DATA / "decisions.parquet")
    z = dec["in_zone"].astype(float)
    sw = dec["swing"].astype(float)
    dec = dec.assign(in_zone=z, o=1 - z, o_sw=(1 - z) * sw, z_sw=z * sw)
    dd = (dec.groupby(["batter", "stand", "season", "game_date", "game_pk"])
             .agg(n_oz=("o", "sum"), n_z=("in_zone", "sum"), o_sw=("o_sw", "sum"), z_sw=("z_sw", "sum"))
             .reset_index())
    dd["chase"] = 100 * dd["o_sw"] / dd["n_oz"].where(dd["n_oz"] > 0)
    dd["z_swing"] = 100 * dd["z_sw"] / dd["n_z"].where(dd["n_z"] > 0)
    dd = dd.drop(columns=["o_sw", "z_sw"])
    g = g.merge(dd, on=["batter", "stand", "season", "game_date", "game_pk"], how="left")

    pa = pd.read_parquet(DATA / "pa.parquet")
    pa = pa.assign(xw=pa["xwoba"] * pa["woba_denom"])
    pg = (pa.groupby(["batter", "stand", "season", "game_date", "game_pk"])
            .agg(n_pa=("woba_denom", "sum"), xw=("xw", "sum")).reset_index())
    pg["xwoba"] = pg["xw"] / pg["n_pa"].where(pg["n_pa"] > 0)
    g = g.merge(pg.drop(columns="xw"), on=["batter", "stand", "season", "game_date", "game_pk"], how="left")

    st_path = DATA / "stance_adj.parquet"
    if st_path.exists():
        st = pd.read_parquet(st_path)
        # doubleheaders: Savant's day value covers both games, so attach it to the day's first game
        g = g.sort_values(["batter", "stand", "game_date", "game_pk"]).reset_index(drop=True)
        first = ~g.duplicated(["batter", "stand", "game_date"])
        st = st.drop_duplicates(["batter", "stand", "game_date"])
        g = g.merge(st[["batter", "stand", "game_date"] + STANCE_METRICS],
                    on=["batter", "stand", "game_date"], how="left")
        for m in STANCE_METRICS:
            g.loc[~first.to_numpy(), m] = np.nan
        g["n_st"] = g.groupby(["batter", "stand", "game_date"])["n_sw"].transform("sum")
    return g.sort_values(["batter", "stand", "game_date", "game_pk"]).reset_index(drop=True)


# --------------------------------------------------------------------------- noise model

@dataclass
class Noise:
    sigma: float      # within-game, per swing (or per pitch for decisions)
    tau: float        # non-persistent game-to-game


def n_col(metric: str) -> str:
    if metric in STANCE_METRICS:
        return "n_st"
    return {"chase": "n_oz", "z_swing": "n_z", "xwoba": "n_pa"}.get(metric, "n_sw")


def estimate_noise(g: pd.DataFrame, metric: str, seasons) -> Noise:
    """Fit E[(y_g - y_{g+1})^2] = 2 tau^2 + sigma^2 (1/n_g + 1/n_{g+1}) on adjacent games."""
    nc = n_col(metric)
    d = g[g["season"].isin(seasons)].dropna(subset=[metric]).sort_values(["batter", "stand", "game_date", "game_pk"])
    d = d[d[nc] > 0]
    key = d["batter"].astype(str) + d["stand"].astype(str) + d["season"].astype(str)
    dy = d.groupby(key)[metric].diff()
    inv = 1 / d[nc] + 1 / d.groupby(key)[nc].shift()
    ok = dy.notna() & inv.notna()
    X = np.column_stack([np.full(ok.sum(), 2.0), inv[ok]])
    coef, *_ = np.linalg.lstsq(X, (dy[ok] ** 2).to_numpy(), rcond=None)
    tau2, sig2 = max(coef[0], 1e-6), max(coef[1], 1e-6)
    return Noise(sigma=float(np.sqrt(sig2)), tau=float(np.sqrt(tau2)))


# --------------------------------------------------------------------------- scan

@dataclass
class Split:
    idx: int            # first game index of the "after" segment (into the arrays passed in)
    z: float
    delta: float
    mu_pre: float
    mu_post: float
    n_pre_games: int
    n_post_games: int
    n_post_obs: float


def best_split(y: np.ndarray, n: np.ndarray, noise: Noise, min_pre_games: int, min_post_games: int,
               min_post_obs: float, max_post_games: int | None = None) -> Split | None:
    """Largest |z| single split of a series (already restricted to the current regime)."""
    ok = ~np.isnan(y) & (n > 0)
    y, n = y[ok], n[ok]
    pos = np.flatnonzero(ok)
    G = len(y)
    if G < min_pre_games + min_post_games:
        return None
    w = 1.0 / (noise.sigma ** 2 / n + noise.tau ** 2)
    cw, cwy, cn = np.cumsum(w), np.cumsum(w * y), np.cumsum(n)
    k = np.arange(min_pre_games, G - min_post_games + 1)        # split before game k
    if max_post_games:
        k = k[G - k <= max_post_games]
    if len(k) == 0:
        return None
    w_pre, wy_pre = cw[k - 1], cwy[k - 1]
    w_post, wy_post = cw[-1] - w_pre, cwy[-1] - wy_pre
    n_post = cn[-1] - cn[k - 1]
    valid = n_post >= min_post_obs
    if not valid.any():
        return None
    mu_pre, mu_post = wy_pre / w_pre, wy_post / w_post
    z = (mu_post - mu_pre) / np.sqrt(1 / w_pre + 1 / w_post)
    z = np.where(valid, z, 0.0)
    j = int(np.argmax(np.abs(z)))
    kk = int(k[j])
    return Split(idx=int(pos[kk]), z=float(z[j]), delta=float(mu_post[j] - mu_pre[j]),
                 mu_pre=float(mu_pre[j]), mu_post=float(mu_post[j]), n_pre_games=kk,
                 n_post_games=G - kk, n_post_obs=float(n_post[j]))
