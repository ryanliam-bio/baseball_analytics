"""
evaluate.py  --  what happened after each flag

persistence():  did the shift hold?  retained = (level over the next N games after
                the flag - pre-change level) / flagged shift.  ~1 = held, ~0 = reverted.
volatility():   how much the hitter's swing metrics wander month to month
                (Benge-style hitters are steady around a new level, Tatis-style are not).
outcomes():     season-to-date line at the flag, the projection we would already have
                had, and the rest-of-season line from the flag date on.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import cpd
import outcomes as oc


def persistence(flags: pd.DataFrame, games: pd.DataFrame, noise: dict, horizon: int = 20) -> pd.DataFrame:
    g = games.sort_values(["batter", "stand", "game_date", "game_pk"])
    by = {k: v for k, v in g.groupby(["batter", "stand", "season"])}
    out = []
    for r in flags.itertuples(index=False):
        hg = by[(r.batter, r.stand, r.season)]
        nxt = hg[hg["game_date"] >= r.flag_date].dropna(subset=[r.metric]).head(horizon)
        if len(nxt) < max(5, horizon // 3):
            out.append((np.nan, np.nan, len(nxt)))
            continue
        nz = noise[r.metric]
        w = 1 / (nz.sigma ** 2 / nxt[cpd.n_col(r.metric)].clip(lower=1) + nz.tau ** 2)
        mu = float(np.average(nxt[r.metric], weights=w))
        out.append((mu, (mu - r.mu_pre) / r.delta, len(nxt)))
    f = flags.copy()
    f[["mu_next", "retained", "next_games"]] = pd.DataFrame(out, index=f.index)
    return f


def concurrent_shift(flags: pd.DataFrame, games: pd.DataFrame, noise: dict, metrics: list[str],
                     post_end_col: str = "flag_date") -> pd.DataFrame:
    """For each flag, the shift in OTHER metrics across the same split: games in
    [regime_start, change_date) vs [change_date, post_end). Returns d_<m> and z_<m>."""
    g = games.sort_values(["batter", "stand", "game_date", "game_pk"])
    by = {k: v for k, v in g.groupby(["batter", "stand", "season"])}
    res = []
    for r in flags.itertuples(index=False):
        hg = by[(r.batter, r.stand, r.season)]
        pre = hg[(hg["game_date"] >= r.regime_start) & (hg["game_date"] < r.change_date)]
        post = hg[(hg["game_date"] >= r.change_date) & (hg["game_date"] < getattr(r, post_end_col))]
        row = {}
        for m in metrics:
            nz, nc = noise[m], cpd.n_col(m)
            a, b = pre.dropna(subset=[m]), post.dropna(subset=[m])
            a, b = a[a[nc] > 0], b[b[nc] > 0]
            if len(a) < 3 or len(b) < 3:
                row["d_" + m], row["z_" + m] = np.nan, np.nan
                continue
            wa = 1 / (nz.sigma ** 2 / a[nc] + nz.tau ** 2)
            wb = 1 / (nz.sigma ** 2 / b[nc] + nz.tau ** 2)
            d = np.average(b[m], weights=wb) - np.average(a[m], weights=wa)
            row["d_" + m] = d
            row["z_" + m] = d / np.sqrt(1 / wa.sum() + 1 / wb.sum())
        res.append(row)
    return pd.concat([flags.reset_index(drop=True), pd.DataFrame(res)], axis=1)


def monthly_volatility(games: pd.DataFrame, metrics: list[str], min_n: int = 40) -> pd.DataFrame:
    """SD of a hitter-season's monthly means, net of sampling noise (sqrt(max(var - mean(se^2), 0)))."""
    g = games.assign(month=games["game_date"].dt.month.clip(4, 9))
    rows = {}
    for m in metrics:
        nc = cpd.n_col(m)
        x = g.dropna(subset=[m])
        mm = (x.assign(wy=x[m] * x[nc]).groupby(["batter", "season", "month"])
                .agg(n=(nc, "sum"), wy=("wy", "sum"), var_sw=(m, "var")))
        mm = mm[mm["n"] >= min_n]
        mm["mu"] = mm["wy"] / mm["n"]
        grp = mm.groupby(level=["batter", "season"])
        v = grp["mu"].var()
        rows[m] = np.sqrt(v.clip(lower=0))
    return pd.DataFrame(rows)


def attach_outcomes(flags: pd.DataFrame, cum: pd.DataFrame, prior: pd.DataFrame, proj: oc.Projection,
                    date_col: str = "flag_date") -> pd.DataFrame:
    rows = []
    for (s, T), grp in flags.groupby(["season", date_col]):
        snap = oc.snapshot(cum, pd.Timestamp(T), s).merge(prior, on=["batter", "season"], how="left")
        snap = snap[snap["batter"].isin(grp["batter"])]
        snap["proj"] = proj.predict(snap)
        rows.append(grp.merge(snap.drop(columns=["season", "as_of"]), on="batter", how="left"))
    f = pd.concat(rows, ignore_index=True)
    f["resid"] = f["ros_xwoba"] - f["proj"]
    f["resid_woba"] = f["ros_woba"] - f["proj"]
    return f


def control_pool(snaps: pd.DataFrame, proj: oc.Projection, min_ros_pa: int = 75) -> pd.DataFrame:
    s = snaps[snaps["ros_pa"] >= min_ros_pa].copy()
    s["proj"] = proj.predict(s)
    s["resid"] = s["ros_xwoba"] - s["proj"]
    s["resid_woba"] = s["ros_woba"] - s["proj"]
    return s


def compare(group: pd.DataFrame, control: pd.DataFrame, col: str = "resid", min_ros_pa: int = 75,
            good: float = 0.025, n_boot: int = 2000, seed: int = 0) -> dict:
    """PA-weighted mean residual of a flag group vs controls taken at the same Mondays."""
    gp = group[group["ros_pa"] >= min_ros_pa].copy()
    if len(gp) == 0:
        return {"n": 0}
    # Matched controls: same Monday, same playing-time band (season-to-date PA quintile among
    # that Monday's controls). The projection regresses everyone to one league mean, which
    # under-projects regulars, and flags come almost entirely from regulars.
    ctl = control.copy()
    ctl["band"] = ctl.groupby(["season", "as_of"])["ytd_pa"].transform(
        lambda s: pd.qcut(s.rank(method="first"), min(5, len(s)), labels=False) if len(s) > 1 else 0)
    edges = ctl.groupby(["season", "as_of", "band"])["ytd_pa"].min().rename("lo").reset_index()
    gp["as_of"] = gp["flag_date"]
    bands = []
    for r in gp[["season", "as_of", "ytd_pa"]].itertuples(index=False):
        e = edges[(edges["season"] == r.season) & (edges["as_of"] == r.as_of)]
        bands.append(int(e.loc[e["lo"] <= r.ytd_pa, "band"].max()) if (e["lo"] <= r.ytd_pa).any() else 0)
    gp["band"] = bands
    flagged = set(zip(gp["batter"], gp["season"], gp["as_of"]))
    ctl = ctl[[k not in flagged for k in zip(ctl["batter"], ctl["season"], ctl["as_of"])]]
    cell = (ctl.assign(wv=ctl[col] * ctl["ros_pa"], good=ctl[col])
               .groupby(["season", "as_of", "band"])
               .agg(wv=("wv", "sum"), w=("ros_pa", "sum"), vals=("good", list)))
    cell["mu"] = cell["wv"] / cell["w"]
    gp = gp.merge(cell[["mu", "vals"]].reset_index(), on=["season", "as_of", "band"], how="inner")
    gp["rel"] = gp[col] - gp["mu"]
    w = gp["ros_pa"].to_numpy()
    diff = np.average(gp["rel"], weights=w)
    ctl_rel = np.concatenate([np.asarray(v) - mu for v, mu in zip(gp["vals"], gp["mu"])])
    # bootstrap over hitter-seasons, not flags: one tinkerer can contribute many flags
    rng = np.random.default_rng(seed)
    v = gp["rel"].to_numpy()
    cl = pd.factorize(gp["batter"].astype(str) + "_" + gp["season"].astype(str))[0]
    members = [np.flatnonzero(cl == k) for k in range(cl.max() + 1)]
    bs = []
    for _ in range(n_boot):
        i = np.concatenate([members[k] for k in rng.integers(0, len(members), len(members))])
        bs.append(np.average(v[i], weights=w[i]))
    lo, hi = np.percentile(bs, [2.5, 97.5])
    return {"n": len(gp), "hitters": len(members), "mean_resid": np.average(gp[col], weights=w), "control_resid": np.average(gp["mu"], weights=w),
            "diff": diff, "ci_lo": lo, "ci_hi": hi, "share_good": float((v > good).mean()),
            "control_share_good": float((ctl_rel > good).mean()), "share_bad": float((v < -good).mean())}
