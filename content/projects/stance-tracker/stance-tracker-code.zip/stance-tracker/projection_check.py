#!/usr/bin/env python3
"""
projection_check.py  --  are the conclusions propped up by an aggressive projection?

Rebuilds the rest-of-season baseline three ways and re-scores the key groups:
  current : fitted blend of last-season wOBA and this-season xwOBA (~43% this season at 300 PA)
  szym    : Marcel-style 3-year preseason projection (5/4/3 weights, regressed), blended with
            this season's xwOBA at PA/(PA+900) -> 25% current season at 300 PA (Szymborski)
  heavy   : same preseason, current-season weight PA/(PA+1800) -> 14% at 300 PA (even more conservative)
Also reports how accurate each baseline is (PA-weighted RMSE of rest-of-season xwOBA).
"""

from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import evaluate as ev
import outcomes as oc

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
SEASONS = [2024, 2025, 2026]


def preseason_table() -> pd.DataFrame:
    """Marcel-style: last 3 seasons of wOBA weighted 5/4/3 by PA, regressed with 200 PA of league average."""
    fg = pd.read_csv(DATA / "fg_woba_hist.csv").rename(columns={"PA": "pa", "wOBA": "woba"})
    pa = oc.load_pa()
    own = pa.groupby(["batter", "season"]).agg(pa=("woba_denom", "sum"), w=("w", "sum")).reset_index()
    own["woba"] = own["w"] / own["pa"]
    own = own.rename(columns={"season": "year"})[["batter", "year", "pa", "woba"]]
    hist = pd.concat([fg[["batter", "year", "pa", "woba"]], own[~own["year"].isin(fg["year"].unique())]])
    rows = []
    for s in SEASONS:
        h = hist[hist["year"].between(s - 3, s - 1)].copy()
        h["wt"] = h["year"].map({s - 1: 5, s - 2: 4, s - 3: 3}) / 5 * h["pa"]
        g = h.assign(wx=h["wt"] * h["woba"]).groupby("batter").agg(wt=("wt", "sum"), wx=("wx", "sum")).reset_index()
        g["season"] = s
        rows.append(g)
    return pd.concat(rows, ignore_index=True)


class Blend:
    def __init__(self, pre: pd.DataFrame, K: float, lg: float, c: float, R: float = 200.0):
        self.pre, self.K, self.lg, self.c, self.R = pre.set_index(["batter", "season"]), K, lg, c, R

    def predict(self, snap: pd.DataFrame) -> np.ndarray:
        idx = pd.MultiIndex.from_arrays([snap["batter"], snap["season"]])
        wt = self.pre["wt"].reindex(idx).fillna(0).to_numpy()
        wx = self.pre["wx"].reindex(idx).fillna(0).to_numpy()
        pre = (wx + wt * self.c + self.R * self.lg) / (wt + self.R)       # wOBA history put on the xwOBA scale
        ytd_pa = snap["ytd_pa"].fillna(0).to_numpy()
        ytd = snap["ytd_xwoba"].fillna(self.lg).to_numpy()
        a = ytd_pa / (ytd_pa + self.K)
        return (1 - a) * pre + a * ytd


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    cur = pickle.load(open(DATA / "projection.pkl", "rb"))
    pre = preseason_table()
    projs = {"current": cur,
             "szym (25% at 300 PA)": Blend(pre, 900, cur.lg, cur.c),
             "heavy (14% at 300 PA)": Blend(pre, 1800, cur.lg, cur.c)}

    # accuracy on every hitter at every Monday (snapshots), 100+ rest-of-season PA
    snaps = pd.read_parquet(DATA / "snapshots.parquet")
    s = snaps[snaps["ros_pa"] >= 100]
    print("Accuracy of each baseline (PA-weighted RMSE of rest-of-season xwOBA; lower is better):")
    for name, p in projs.items():
        e = s["ros_xwoba"] - p.predict(s)
        mid = s[(s["ytd_pa"] >= 250) & (s["ytd_pa"] <= 350)]
        em = mid["ros_xwoba"] - p.predict(mid)
        print(f"  {name:<24} all {np.sqrt(np.average(e ** 2, weights=s['ros_pa'])):.4f}   "
              f"midseason (250-350 PA) {np.sqrt(np.average(em ** 2, weights=mid['ros_pa'])):.4f}")
    w300 = 300 / (300 + 0.4 * 600 + 150)
    print(f"  (current weight on this season at 300 PA with 600 prior PA: {w300:.0%})")

    fl = pd.concat([pd.read_csv(RESULTS / f"flags_{y}_scored.csv", parse_dates=["flag_date", "change_date"])
                    for y in SEASONS], ignore_index=True)
    ins = fl[fl["kind"] == "in-season"]
    conf = pd.read_csv(RESULTS / "followups_stance_swing_quality.csv", parse_dates=["flag_date", "change_date"])
    first = lambda x: x.sort_values("flag_date").drop_duplicates(["batter", "season"])
    m, d = ins["metric"], ins["delta"]
    groups = {
        "feet narrowed 4.5+ in": first(ins[(m == "foot_sep") & (d < 0)]),
        "feet widened 4.5+ in": first(ins[(m == "foot_sep") & (d > 0)]),
        "opened 15+ deg": first(ins[(m == "stance_angle") & (d <= -15)]),
        "closed 15+ deg": first(ins[(m == "stance_angle") & (d >= 15)]),
        "stance angle 12-15 deg": first(ins[(m == "stance_angle") & (d.abs() < 15)]),
        "box position moved": first(ins[m.isin(["dist_off_plate", "depth_in_box"])]),
        "bat speed up 2+ mph": first(ins[(m == "bat_speed") & (d > 0)]),
        "swing xwOBA up .010+ (3-wk read)": first(conf[conf["dq"] >= 0.010]),
        "swing xwOBA flat (3-wk read)": first(conf[conf["dq"].abs() < 0.010]),
    }
    dates = {y: sorted(pd.concat([g.loc[g["season"] == y, "flag_date"] for g in groups.values()]).unique())
             for y in SEASONS}
    ctl_snaps = oc.all_snapshots(cum, prior, dates)
    ctl_snaps = ctl_snaps[ctl_snaps["ros_pa"] >= 75].copy()

    # how far the groups were running below their baselines when flagged (slump depth)
    rows = []
    print("\nRest of season vs each baseline, relative to matched controls (first flag per hitter-season, 2024-26):")
    print(f"  {'group':<34} " + "  ".join(f"{n:>30}" for n in projs))
    for gname, g in groups.items():
        g = g.copy()
        cells = []
        for pname, p in projs.items():
            g["r"] = g["ros_xwoba"] - p.predict(g)
            c = ctl_snaps.copy()
            c["r"] = c["ros_xwoba"] - p.predict(c)
            r = ev.compare(g.dropna(subset=["r"]), c, col="r", n_boot=1000)
            slump = np.average((g["ytd_xwoba"] - p.predict(g)).fillna(0), weights=g["ros_pa"].fillna(0) + 1e-9)
            cells.append(f"{r['diff']:+.3f} [{r['ci_lo']:+.3f},{r['ci_hi']:+.3f}] {r['share_good']:.0%}")
            rows.append(dict(group=gname, projection=pname, hitters=r["hitters"], diff=r["diff"], ci_lo=r["ci_lo"],
                             ci_hi=r["ci_hi"], beat=r["share_good"], ctl_beat=r["control_share_good"],
                             ytd_vs_baseline=slump))
        print(f"  {gname:<34} " + "  ".join(f"{x:>30}" for x in cells))
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "projection_check.csv", index=False)
    print("\nHow far below each baseline the group was running when flagged (season-to-date xwOBA minus baseline):")
    print(out.pivot(index="group", columns="projection", values="ytd_vs_baseline").round(3).to_string())


if __name__ == "__main__":
    main()
