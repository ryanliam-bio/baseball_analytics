#!/usr/bin/env python3
"""figures.py  --  Benge vs Tatis timelines and the effect-size summary (results/*.png)."""

from __future__ import annotations

from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import outcomes as oc

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"

SURFACE, INK, INK2, MUTED, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#8f8d87", "#e6e5e1"
BLUE, ORANGE = "#2a78d6", "#eb6834"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "text.color": INK, "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold",
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.8, "axes.axisbelow": True,
})


def timelines() -> None:
    g = pd.read_parquet(DATA / "games.parquet")
    flags = pd.read_csv(RESULTS / "flags_2026.csv", parse_dates=["flag_date", "change_date"])
    pa = oc.load_pa()
    players = [(701807, "Carson Benge", BLUE), (665487, "Fernando Tatis Jr.", ORANGE)]
    rows = [("stance_angle", "Stance angle (deg, + = closed)"), ("foot_sep", "Foot separation (in)"),
            ("ad_pull", "Attack direction, location-adj. (deg, + = pull)"), ("xwoba", "xwOBA, rolling 100 PA")]
    fig, axes = plt.subplots(len(rows), 2, figsize=(11, 10.5), sharex="col", sharey="row")
    for j, (pid, name, color) in enumerate(players):
        s = g[(g["batter"] == pid) & (g["season"] == 2026)].sort_values("game_date")
        f = flags[(flags["batter"] == pid) & flags["level"].isin(["SIGNAL", "STANCE"])
                  & flags["metric"].isin(["stance_angle", "foot_sep"])]
        for i, (m, lab) in enumerate(rows):
            ax = axes[i, j]
            if m == "xwoba":
                p = pa[(pa["batter"] == pid) & (pa["season"] == 2026)].sort_values(["game_date", "at_bat_number"])
                roll = (p["xw"].rolling(100, min_periods=60).sum() / p["woba_denom"].rolling(100, min_periods=60).sum())
                ax.plot(p["game_date"], roll, color=color, lw=2)
                ax.axhline(0.320, color=MUTED, lw=1, ls=(0, (4, 3)))
                if j == 0:
                    ax.text(s["game_date"].min(), 0.323, "league avg", color=INK2, fontsize=8, va="bottom")
            else:
                d = s.dropna(subset=[m])
                ax.scatter(d["game_date"], d[m], s=9, color=MUTED, alpha=0.45, lw=0)
                w = d[m].rolling(7, min_periods=4, center=True).mean()
                ax.plot(d["game_date"], w, color=color, lw=2)
            for r in f.itertuples():
                ls = "-" if r.level == "SIGNAL" else (0, (2, 2))
                ax.axvline(r.flag_date, color=INK, lw=0.9, ls=ls, alpha=0.55 if r.metric == m else 0.18)
            if j == 0:
                ax.set_ylabel(lab, fontsize=9)
            if i == 0:
                ax.set_title(name, color=INK, loc="left")
        axes[-1, j].xaxis.set_major_locator(mdates.MonthLocator())
        axes[-1, j].xaxis.set_major_formatter(mdates.DateFormatter("%b"))
    fig.suptitle("2026 replay: stance flags as the tracker would have raised them (solid = SIGNAL, dashed = STANCE; darker = that row's metric)",
                 fontsize=10, color=INK2, x=0.01, ha="left", y=0.995)
    fig.text(0.01, 0.003, "Grey dots: one game. Lines: 7-game centred mean. Stance from Savant per-day batting stance; "
             "attack direction adjusted for pitch location, type, count and park.", fontsize=8, color=INK2)
    fig.tight_layout(rect=(0, 0.015, 1, 0.98))
    fig.savefig(RESULTS / "benge-vs-tatis-2026.png", dpi=160)
    plt.close(fig)


def effects() -> None:
    order = [
        (None, "feet narrowed 4.5+ in", "Feet narrowed 4.5+ in"),
        (None, "feet widened 4.5+ in", "Feet widened 4.5+ in"),
        (None, "stance opened 15+ deg", "Opened 15+ deg"),
        (None, "stance closed 15+ deg", "Closed 15+ deg"),
        (None, "stance angle 12-15 deg", "Stance angle 12-15 deg"),
        (None, "box position moved", "Box position moved"),
        (None, "offseason stance change", "Offseason stance change"),
        (None, "stance change, swing moved too", "Stance change, swing moved too"),
        (None, "stance change, swing did not move", "Stance change, swing did not move"),
        (None, "bat speed up 2+ mph", "Bat speed up 2+ mph"),
        (None, "attack direction shift", "Attack direction shift"),
        (None, "contact depth shift", "Contact depth shift"),
        (None, "attack angle shift", "Attack angle shift"),
    ]
    sets = [("2024-25 (thresholds set here)", RESULTS / "groups_2024+2025.csv", BLUE, -0.17),
            ("2026 (out of sample)", RESULTS / "groups_2026.csv", ORANGE, 0.17)]
    fig, ax = plt.subplots(figsize=(9.5, 7.6))
    ylabels = []
    for k, (_, key, lab) in enumerate(order):
        y = len(order) - 1 - k
        ylabels.append((y, lab))
        for name, path, color, off in sets:
            t = pd.read_csv(path)
            r = t[(t["group"] == key) & (t["cut"] == "first per hitter")]
            if r.empty or pd.isna(r["diff"].iloc[0]):
                continue
            r = r.iloc[0]
            ax.plot([r["ci_lo"] * 1000, r["ci_hi"] * 1000], [y + off] * 2, color=color, lw=2, solid_capstyle="round")
            ax.scatter([r["diff"] * 1000], [y + off], s=46, color=color, zorder=3, edgecolor=SURFACE, linewidth=2)
            ax.text(1.01, y + off, f"{int(r['hitters'])}", color=INK2, fontsize=8, va="center", ha="left",
                    transform=ax.get_yaxis_transform())
    ax.axvline(0, color=INK2, lw=1)
    ax.set_yticks([y for y, _ in ylabels], [l for _, l in ylabels])
    ax.set_xlim(-22, 52)
    ax.set_xlabel("Rest-of-season xwOBA vs projection, relative to matched controls (points of xwOBA, 95% CI)")
    ax.grid(axis="y", visible=False)
    ax.text(1.01, len(order) - 0.45, "hitters", color=INK2, fontsize=8, ha="left", transform=ax.get_yaxis_transform())
    for name, _, color, _ in sets:
        ax.scatter([], [], s=46, color=color, label=name)
    ax.legend(loc="lower right", frameon=False, fontsize=9)
    ax.set_title("Which flagged changes were followed by better-than-projected hitting?", loc="left")
    fig.text(0.01, 0.012, "First flag per hitter-season, measured from the flag date (what you could act on).\n"
             "Controls: hitters on the same day in the same playing-time band. CIs resample hitters.",
             fontsize=8, color=INK2)
    fig.tight_layout(rect=(0, 0.05, 0.97, 1))
    fig.savefig(RESULTS / "effect-sizes.png", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    timelines()
    effects()
    print("wrote results/benge-vs-tatis-2026.png, results/effect-sizes.png")
