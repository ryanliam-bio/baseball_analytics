#!/usr/bin/env python3
"""
replay_eval.py  --  score a season replay (default 2026, thresholds set on 2024-25 only)

Reads results/flags_<season>.csv from `tracker.py --replay <season>` and adds:
  persistence (hindsight), same-split shifts in the other metrics, the season-to-date
  line and projection at the flag, the rest-of-season line, and the residual vs
  matched controls (same day, same playing-time band).
Writes results/flags_<season>_scored.csv and prints group tables.
"""

from __future__ import annotations

import argparse
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import cpd
import evaluate as ev
import outcomes as oc
import tracker

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
OTHER = [m for m in cpd.STANCE_METRICS + cpd.SWING_METRICS if m != "com_off_plate"]


def score(season: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    t = tracker.load_thresholds()
    g = tracker.load_games()
    path = RESULTS / f"flags_{season}.csv"
    if not path.exists():
        tracker.run_all(g, season, t).to_csv(path, index=False)
    fl = pd.read_csv(path, parse_dates=["flag_date", "change_date", "regime_start"])
    fl = ev.persistence(fl, g, t["noise"])
    fl = ev.concurrent_shift(fl, g, t["noise"], OTHER)
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    fl = ev.attach_outcomes(fl, cum, prior, proj)
    days = sorted(fl["flag_date"].unique())
    ctl = ev.control_pool(oc.all_snapshots(cum, prior, {season: days}), proj)
    fl["lag_days"] = (fl["flag_date"] - fl["change_date"]).dt.days
    return fl, ctl


def fmt(r: dict) -> str:
    if not r.get("n"):
        return "n=0"
    return (f"{r['n']:>3} flags/{r['hitters']:>3} hitters  {r['diff']:+.3f} [{r['ci_lo']:+.3f},{r['ci_hi']:+.3f}]  "
            f"beat .025+: {r['share_good']:.0%} (ctl {r['control_share_good']:.0%})  short .025+: {r['share_bad']:.0%}")


def first_per_hitter(x: pd.DataFrame) -> pd.DataFrame:
    return x.sort_values("flag_date").drop_duplicates(["batter", "season"])


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("--seasons", type=int, nargs="+", default=[2026])
    args = p.parse_args()
    parts = [score(s) for s in args.seasons]
    for s, (f, _) in zip(args.seasons, parts):
        f.to_csv(RESULTS / f"flags_{s}_scored.csv", index=False)
    fl = pd.concat([f for f, _ in parts], ignore_index=True)
    ctl = pd.concat([c for _, c in parts], ignore_index=True)
    tag = "+".join(map(str, args.seasons))

    print(f"== {tag} replay: {len(fl)} flags")
    print(fl.groupby(["level", "metric"]).agg(n=("z", "size"), hitters=("batter", "nunique"),
                                              lag_med=("lag_days", "median"),
                                              held=("retained", lambda s: (s >= .5).mean())).round(2).to_string())
    ins = fl[fl["kind"] == "in-season"]
    m, d = ins["metric"], ins["delta"]
    groups = {
        "feet narrowed 4.5+ in": ins[(m == "foot_sep") & (d < 0)],
        "feet widened 4.5+ in": ins[(m == "foot_sep") & (d > 0)],
        "stance opened 15+ deg": ins[(m == "stance_angle") & (d <= -15)],
        "stance closed 15+ deg": ins[(m == "stance_angle") & (d >= 15)],
        "stance angle 12-15 deg": ins[(m == "stance_angle") & (d.abs() < 15)],
        "box position moved": ins[m.isin(["dist_off_plate", "depth_in_box"])],
        "bat speed up 2+ mph": ins[(m == "bat_speed") & (d > 0)],
        "bat speed down 2+ mph": ins[(m == "bat_speed") & (d < 0)],
        "attack direction shift": ins[m == "ad_pull"],
        "contact depth shift": ins[m == "depth"],
        "attack angle shift": ins[m == "attack_angle"],
        "any SIGNAL": ins[ins["level"] == "SIGNAL"],
        "any other stance change": ins[ins["level"] == "STANCE"],
        "offseason stance change": fl[(fl["kind"] == "offseason") & fl["metric"].isin(cpd.STANCE_METRICS)],
        "offseason swing change": fl[(fl["kind"] == "offseason") & ~fl["metric"].isin(cpd.STANCE_METRICS)],
    }
    st = ins[m.isin(["stance_angle", "foot_sep"])]
    moved = (st[["z_ad_pull", "z_depth", "z_attack_angle", "z_bat_speed"]].abs() >= 2.5).any(axis=1)
    groups["stance change, swing moved too"] = st[moved]
    groups["stance change, swing did not move"] = st[~moved]
    print("\nRest-of-season xwOBA vs projection, from the flag date, relative to matched controls")
    rows = []
    for k, x in groups.items():
        r_all, r_first = ev.compare(x, ctl), ev.compare(first_per_hitter(x), ctl)
        print(f"  {k:<36} all:   {fmt(r_all)}")
        print(f"  {'':<36} first: {fmt(r_first)}")
        rows += [dict(group=k, cut="all flags", **r_all), dict(group=k, cut="first per hitter", **r_first)]
    pd.DataFrame(rows).to_csv(RESULTS / f"groups_{tag}.csv", index=False)


if __name__ == "__main__":
    main()
