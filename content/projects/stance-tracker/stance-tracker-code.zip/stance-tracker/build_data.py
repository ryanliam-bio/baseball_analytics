#!/usr/bin/env python3
"""
build_data.py  --  swing and PA tables for the changepoint tracker

Reads the daily pitch-level cache written by ../bat-speed-three/savant_swings.py
(../savant_cache/YEAR/DATE.csv.gz, every regular-season pitch) and writes:

    data/swings.parquet   competitive, tracked, non-bunt swings with the
                          handedness-normalised features the adjustment models use
    data/pa.parquet       one row per PA with wOBA / xwOBA credit (for outcomes)
    data/decisions.parquet  every pitch with zone + swing flag (chase / zone-swing rates)

Run:  python build_data.py [--seasons 2024 2025 2026]
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PITCH_CACHE = HERE.parent / "savant_cache"
DATA = HERE / "data"

USECOLS = [
    "game_date", "game_type", "game_pk", "at_bat_number", "pitch_number", "inning_topbot", "home_team", "zone",
    "batter", "pitcher", "player_name", "stand", "p_throws", "balls", "strikes",
    "pitch_type", "release_speed", "api_break_x_batter_in", "api_break_z_with_gravity",
    "plate_x", "plate_z", "sz_top", "sz_bot", "vx0", "vy0", "vz0", "ax", "ay", "az",
    "description", "events", "des", "bb_type", "type",
    "launch_speed", "launch_angle", "hc_x", "hc_y",
    "estimated_woba_using_speedangle", "woba_value", "woba_denom", "delta_run_exp",
    "bat_speed", "swing_length", "attack_angle", "attack_direction", "swing_path_tilt",
    "intercept_ball_minus_batter_pos_x_inches", "intercept_ball_minus_batter_pos_y_inches",
]
SWINGS = {"foul", "foul_tip", "hit_into_play", "swinging_strike", "swinging_strike_blocked",
          "foul_pitchout", "swinging_pitchout"}
BUNT_DESC = {"foul_bunt", "missed_bunt", "bunt_foul_tip"}
PITCH_GROUP = {
    "FF": "FB", "SI": "FB", "FC": "FB",
    "SL": "BR", "ST": "BR", "CU": "BR", "KC": "BR", "SV": "BR", "CS": "BR", "SC": "BR",
    "CH": "OS", "FS": "OS", "FO": "OS", "KN": "OS", "EP": "OS",
}
COMPETITIVE_FLOOR_MPH = 50.0  # flat floor; 3.0 found it ~identical to the IQR rule and it has no look-ahead


def load_season(year: int) -> pd.DataFrame:
    files = sorted((PITCH_CACHE / str(year)).glob("*.csv.gz"))
    frames = []
    for f in files:
        df = pd.read_csv(f, usecols=lambda c: c in USECOLS, low_memory=False)
        frames.append(df[df["game_type"] == "R"])
    df = pd.concat(frames, ignore_index=True)
    df["game_date"] = pd.to_datetime(df["game_date"])
    df["season"] = year
    print(f"{year}: {len(files)} days, {len(df):,} regular-season pitches", flush=True)
    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    s = np.where(df["stand"] == "R", 1.0, -1.0)  # plate_x is catcher's view; RHB stands at -x
    df["hand_sign"] = s
    df["inside_in"] = -df["plate_x"] * s * 12.0                       # + = inside, inches
    df["z_rel"] = (df["plate_z"] - df["sz_bot"]) / (df["sz_top"] - df["sz_bot"])
    df["pgroup"] = df["pitch_type"].map(PITCH_GROUP).fillna("OS")
    df["same_side"] = (df["stand"] == df["p_throws"]).astype(np.int8)
    # spray angle, + = pull side (Savant hc coords: home plate ~ (125.42, 198.27))
    ang = np.degrees(np.arctan2(df["hc_x"] - 125.42, 198.27 - df["hc_y"]))
    df["spray_pull"] = -ang * s
    # ball speed at the front of the plate (ft/s) from the 9-parameter fit, for depth-in-ms
    y0, yf = 50.0, 17.0 / 12.0
    disc = df["vy0"] ** 2 - 2 * df["ay"] * (y0 - yf)
    t = (-df["vy0"] - np.sqrt(disc)) / df["ay"]
    df["vy_plate"] = -(df["vy0"] + df["ay"] * t)
    return df


def build_swings(df: pd.DataFrame) -> pd.DataFrame:
    sw = df[df["description"].isin(SWINGS)].copy()
    bunt = sw["description"].isin(BUNT_DESC) | sw["des"].astype(str).str.contains("bunt", case=False, na=False)
    sw = sw[~bunt & sw["bat_speed"].notna() & sw["attack_direction"].notna()
            & sw["intercept_ball_minus_batter_pos_y_inches"].notna()]
    sw = sw[sw["bat_speed"] >= COMPETITIVE_FLOOR_MPH]
    sw = sw.rename(columns={"intercept_ball_minus_batter_pos_x_inches": "int_x",
                            "intercept_ball_minus_batter_pos_y_inches": "int_y"})
    sw["contact"] = sw["description"].isin({"foul", "foul_tip", "hit_into_play"}).astype(np.int8)
    sw["in_play"] = (sw["description"] == "hit_into_play").astype(np.int8)
    sw["depth_ms"] = sw["int_y"] / 12.0 / sw["vy_plate"] * 1000.0
    # Lateral distance from the hitter's CoM to the plate's centreline at contact.
    # int_x is CoM-to-ball (always +); adding how far inside the pitch was gives CoM-to-centreline.
    sw["com_off_plate"] = sw["int_x"] + sw["inside_in"]
    keep = ["season", "game_date", "game_pk", "home_team", "at_bat_number", "pitch_number", "batter", "player_name",
            "stand", "p_throws", "same_side", "balls", "strikes", "pitch_type", "pgroup", "release_speed",
            "api_break_x_batter_in", "api_break_z_with_gravity", "plate_x", "plate_z", "inside_in", "z_rel",
            "sz_top", "sz_bot", "vy_plate", "description", "contact", "in_play", "bb_type", "launch_speed",
            "launch_angle", "spray_pull", "estimated_woba_using_speedangle", "delta_run_exp",
            "bat_speed", "swing_length", "attack_angle", "attack_direction", "swing_path_tilt",
            "int_x", "int_y", "depth_ms", "com_off_plate"]
    sw = sw[keep].sort_values(["batter", "game_date", "game_pk", "at_bat_number", "pitch_number"])
    for c in sw.select_dtypes("float64").columns:
        sw[c] = sw[c].astype("float32")
    return sw.reset_index(drop=True)


def build_decisions(df: pd.DataFrame) -> pd.DataFrame:
    """Every pitch with a swing flag, for chase / zone-swing rates."""
    d = df[df["zone"].notna() & ~df["description"].isin(BUNT_DESC | {"pitchout", "hit_by_pitch"})]
    d = d[~d["des"].astype(str).str.contains("bunt", case=False, na=False) | ~d["description"].isin(SWINGS)]
    out = d[["season", "game_date", "game_pk", "home_team", "batter", "stand", "balls", "strikes", "zone"]].copy()
    out["in_zone"] = (out["zone"] <= 9).astype(np.int8)
    out["swing"] = d["description"].isin(SWINGS).astype(np.int8)
    out["whiff"] = d["description"].isin({"swinging_strike", "swinging_strike_blocked"}).astype(np.int8)
    return out.drop(columns="zone").reset_index(drop=True)


def build_pa(df: pd.DataFrame) -> pd.DataFrame:
    pa = df[df["events"].notna() & (df["events"] != "truncated_pa")].copy()
    pa = pa[pa["woba_denom"].fillna(0) > 0]
    bip = pa["type"] == "X"
    pa["xwoba"] = np.where(bip & pa["estimated_woba_using_speedangle"].notna(),
                           pa["estimated_woba_using_speedangle"], pa["woba_value"])
    pa["k"] = pa["events"].isin({"strikeout", "strikeout_double_play"}).astype(np.int8)
    pa["bb"] = pa["events"].isin({"walk", "intent_walk"}).astype(np.int8)
    pa["bip"] = bip.astype(np.int8)
    pa["barrel_proxy"] = ((pa["launch_speed"] >= 98) &
                          (pa["launch_angle"].between(26 - (pa["launch_speed"] - 98), 30 + 2 * (pa["launch_speed"] - 98)))
                          ).astype(np.int8)
    keep = ["season", "game_date", "game_pk", "at_bat_number", "batter", "player_name", "stand",
            "events", "woba_value", "woba_denom", "xwoba", "k", "bb", "bip", "launch_speed",
            "launch_angle", "spray_pull", "barrel_proxy", "delta_run_exp"]
    return pa[keep].sort_values(["batter", "game_date", "game_pk", "at_bat_number"]).reset_index(drop=True)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--seasons", type=int, nargs="+", default=[2024, 2025, 2026])
    args = p.parse_args()
    DATA.mkdir(exist_ok=True)
    sw_all, pa_all, dec_all = [], [], []
    for yr in args.seasons:
        df = add_features(load_season(yr))
        sw_all.append(build_swings(df))
        pa_all.append(build_pa(df))
        dec_all.append(build_decisions(df))
        print(f"   swings {len(sw_all[-1]):,}   PAs {len(pa_all[-1]):,}", flush=True)
    pd.concat(sw_all, ignore_index=True).to_parquet(DATA / "swings.parquet", index=False)
    pd.concat(pa_all, ignore_index=True).to_parquet(DATA / "pa.parquet", index=False)
    pd.concat(dec_all, ignore_index=True).to_parquet(DATA / "decisions.parquet", index=False)
    print("wrote data/swings.parquet, data/pa.parquet, data/decisions.parquet")


if __name__ == "__main__":
    main()
