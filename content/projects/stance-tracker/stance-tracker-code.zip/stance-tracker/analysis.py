#!/usr/bin/env python3
"""
analysis.py  --  calibrate thresholds on 2024-25, then replay 2026 week by week

Steps
  1. park-adjust Savant per-day stance, build the hitter-game table (all metrics)
  2. noise model per metric from 2024-25 adjacent-game differences
  3. z threshold per metric from a no-change null simulation (season false-flag rate)
  4. run the tracker on 2024-25 with z only, then study flag size vs persistence and
     rest-of-season performance to set the magnitude thresholds (delta)
  5. write thresholds.json, replay 2026 with them, evaluate the 2026 flags

Outputs in results/.
"""

from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

import cpd
import evaluate as ev
import outcomes as oc
import tracker

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
HIST = [2024, 2025]
SIM = 2026
Z_NULL_QUANTILE = 0.99            # <= 1% of no-change hitter-seasons get a false flag, per metric

# Metrics that can raise a flag. com_off_plate / chase / z_swing are reported as context only:
# the first mostly tracks slow drift (2.3 flags per regular per season with no outcome signal),
# the decision rates are too noisy per game to move inside a few weeks.
TRIGGERS = cpd.STANCE_METRICS + ["ad_pull", "depth", "ad_at_depth", "bat_speed", "attack_angle", "tilt"]
CONTEXT = ["com_off_plate", "chase", "z_swing"]


def step_data() -> pd.DataFrame:
    cpd.adjust_stance(HIST)
    g = cpd.build_game_table(HIST)
    g.to_parquet(DATA / "games.parquet", index=False)
    return g


def step_noise(g: pd.DataFrame) -> dict[str, cpd.Noise]:
    return {m: cpd.estimate_noise(g, m, HIST) for m in TRIGGERS + CONTEXT}


def step_z(g: pd.DataFrame, noise: dict) -> dict[str, float]:
    z = {}
    for m in TRIGGERS + CONTEXT:
        mx = tracker.null_season_max_z(g, HIST, m, noise[m], reps=2)
        z[m] = float(np.round(np.quantile(mx, Z_NULL_QUANTILE), 2))
    return z


def load_outcome_inputs():
    pa = oc.load_pa()
    cum = oc.daily_cum(pa)
    prior = oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    snaps = pd.read_parquet(DATA / "snapshots.parquet")
    return cum, prior, proj, snaps


def main() -> None:
    RESULTS.mkdir(exist_ok=True)
    g = step_data()
    noise = step_noise(g)
    z = step_z(g, noise)
    print("noise:", {m: (round(n.sigma, 2), round(n.tau, 2)) for m, n in noise.items()})
    print("z thresholds:", z)
    zero = {m: 0.0 for m in z}
    hist = pd.concat([tracker.run_online(g, s, TRIGGERS + CONTEXT, noise, z, zero) for s in HIST])
    hist = ev.persistence(hist, g, noise)
    cum, prior, proj, snaps = load_outcome_inputs()
    hist = ev.attach_outcomes(hist, cum, prior, proj)
    hist.to_parquet(RESULTS / "flags_hist_nodelta.parquet", index=False)
    json.dump({"noise": {m: {"sigma": n.sigma, "tau": n.tau} for m, n in noise.items()}, "z": z},
              open(RESULTS / "calibration_stage1.json", "w"), indent=1)
    print(f"{len(hist)} historical flags (no magnitude threshold) -> results/flags_hist_nodelta.parquet")


if __name__ == "__main__":
    main()
