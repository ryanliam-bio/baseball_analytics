#!/usr/bin/env python3
"""
robustness.py  --  do the flag effects survive controls, and how misleading is before/after?

Panel: every hitter with 75+ rest-of-season PA on every date a flag fired (2024-26).
Outcome: rest-of-season xwOBA minus projection (PA-weighted).
Model:   resid ~ flag-type indicators + age + age^2 + rookie + (ytd xwOBA - proj) + log(ytd PA),
         with same-date fixed effects (within-date demeaning) and SEs clustered by hitter.
Also reports the naive "after minus before" change (ROS xwOBA - season-to-date xwOBA) for
flagged hitters and for everyone else on the same dates.

Writes results/robustness.csv
"""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

import evaluate as ev
import outcomes as oc

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
SEASONS = [2024, 2025, 2026]


def groups(fl: pd.DataFrame) -> dict[str, pd.Series]:
    m, d = fl["metric"].where(fl["kind"] == "in-season"), fl["delta"]   # offseason flags handled separately
    return {
        "feet narrowed 4.5+ in": (m == "foot_sep") & (d < 0),
        "feet widened 4.5+ in": (m == "foot_sep") & (d > 0),
        "stance opened 15+ deg": (m == "stance_angle") & (d <= -15),
        "stance closed 15+ deg": (m == "stance_angle") & (d >= 15),
        "stance angle 12-15 deg": (m == "stance_angle") & (d.abs() < 15),
        "box position moved": m.isin(["dist_off_plate", "depth_in_box"]),
        "bat speed up 2+ mph": (m == "bat_speed") & (d > 0),
        "bat speed down 2+ mph": (m == "bat_speed") & (d < 0),
        "attack direction shift": m == "ad_pull",
        "contact depth shift": m == "depth",
        "attack angle shift": m == "attack_angle",
    }


def main() -> None:
    fl = pd.concat([pd.read_csv(RESULTS / f"flags_{s}_scored.csv", parse_dates=["flag_date", "change_date"])
                    for s in SEASONS], ignore_index=True)
    G = groups(fl)
    firsts = {k: fl[v].sort_values("flag_date").drop_duplicates(["batter", "season"]) for k, v in G.items()}

    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    dates = {s: sorted(pd.concat([f.loc[f["season"] == s, "flag_date"] for f in firsts.values()]).unique())
             for s in SEASONS}
    panel = ev.control_pool(oc.all_snapshots(cum, prior, dates), proj)
    panel = panel.merge(pd.read_parquet(DATA / "ages.parquet"), on=["batter", "season"], how="left")
    panel["age"] = panel["age"].fillna(panel["age"].median())
    panel["age_c"] = panel["age"] - 28
    panel["age2"] = panel["age_c"] ** 2
    panel["rookie"] = (panel["prior_pa"].fillna(0) < 150).astype(float)
    panel["slump"] = (panel["ytd_xwoba"] - panel["proj"]).fillna(0)
    panel["log_ytd_pa"] = np.log1p(panel["ytd_pa"])
    key = ["batter", "season", "as_of"]
    for k, f in firsts.items():
        tag = f[["batter", "season", "flag_date"]].rename(columns={"flag_date": "as_of"}).assign(**{k: 1.0})
        panel = panel.merge(tag.drop_duplicates(key), on=key, how="left")
        panel[k] = panel[k].fillna(0.0)

    names = list(firsts)
    controls = ["age_c", "age2", "rookie", "slump", "log_ytd_pa"]
    X = panel[names + controls].astype(float)
    y = panel["resid"].astype(float)
    w = panel["ros_pa"].astype(float)
    date_id = panel["season"].astype(str) + panel["as_of"].astype(str)
    # within-date weighted demeaning == date fixed effects
    def demean(s):
        return s - (s * w).groupby(date_id).transform("sum") / w.groupby(date_id).transform("sum")
    Xd = X.apply(demean)
    yd = demean(y)
    res = sm.WLS(yd, Xd, weights=w).fit(cov_type="cluster", cov_kwds={"groups": panel["batter"]})

    rows = []
    for k in names:
        flagged = panel[k] == 1
        same_dates = date_id.isin(date_id[flagged])
        naive_f = np.average(panel.loc[flagged, "ros_xwoba"] - panel.loc[flagged, "ytd_xwoba"].fillna(panel.loc[flagged, "proj"]),
                             weights=panel.loc[flagged, "ros_pa"])
        others = same_dates & ~flagged
        naive_c = np.average(panel.loc[others, "ros_xwoba"] - panel.loc[others, "ytd_xwoba"].fillna(panel.loc[others, "proj"]),
                             weights=panel.loc[others, "ros_pa"])
        lo, hi = res.conf_int().loc[k]
        rows.append(dict(group=k, hitters=int(flagged.sum()),
                         naive_after_minus_before=naive_f, naive_controls=naive_c,
                         vs_projection=np.average(panel.loc[flagged, "resid"], weights=panel.loc[flagged, "ros_pa"]),
                         adjusted=res.params[k], ci_lo=lo, ci_hi=hi, p=res.pvalues[k],
                         mean_age=panel.loc[flagged, "age"].mean(), rookie_share=panel.loc[flagged, "rookie"].mean(),
                         mean_slump=np.average(panel.loc[flagged, "slump"], weights=panel.loc[flagged, "ros_pa"])))
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "robustness.csv", index=False)
    pd.set_option("display.width", 200)
    print(out.round(3).to_string(index=False))
    # contrasts against other stance changers: both sides are tinkering regulars, so anything that
    # makes flagged hitters in general beat projection (e.g. 2026) cancels out
    cols = list(Xd.columns)
    contrasts = {
        "narrowed - widened": {"feet narrowed 4.5+ in": 1, "feet widened 4.5+ in": -1},
        "narrowed - other stance changes (avg of widened, 12-15 deg, box)":
            {"feet narrowed 4.5+ in": 1, "feet widened 4.5+ in": -1 / 3, "stance angle 12-15 deg": -1 / 3,
             "box position moved": -1 / 3},
        "opened - closed": {"stance opened 15+ deg": 1, "stance closed 15+ deg": -1},
    }
    crow = []
    for lab, wts in contrasts.items():
        L = np.array([[wts.get(c, 0.0) for c in cols]])
        tt = res.t_test(L)
        lo, hi = np.asarray(tt.conf_int()).ravel()
        crow.append(dict(contrast=lab, estimate=float(np.asarray(tt.effect).ravel()[0]), ci_lo=lo, ci_hi=hi,
                         p=float(np.asarray(tt.pvalue).ravel()[0])))
    cdf = pd.DataFrame(crow)
    cdf.to_csv(RESULTS / "robustness_contrasts.csv", index=False)
    print()
    print(cdf.round(3).to_string(index=False))
    print("\ncontrols:", {c: (round(res.params[c], 4), round(res.pvalues[c], 3)) for c in controls})
    print(f"panel rows {len(panel):,}, hitters {panel['batter'].nunique():,}, mean age {panel['age'].mean():.1f}, "
          f"rookie share {panel['rookie'].mean():.2f}")


if __name__ == "__main__":
    main()
