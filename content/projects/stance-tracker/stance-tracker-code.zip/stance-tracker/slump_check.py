#!/usr/bin/env python3
"""
slump_check.py  --  is the edge just slumping hitters regressing back (and is 2026's lift that)?

1. How far below projection were flagged hitters at the CHANGE date and at the FLAG date, vs everyone.
2. Projection calibration by slump: among all hitters on the same Mondays, does rest-of-season
   residual depend on how far season-to-date ran from projection? (per season)
3. Re-score key groups with controls matched on date, playing time AND slump depth (quintile of
   season-to-date xwOBA minus projection), per season and pooled.
"""

from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

import evaluate as ev
import outcomes as oc

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
SEASONS = [2024, 2025, 2026]


def compare_slump_matched(g: pd.DataFrame, ctl: pd.DataFrame, n_boot: int = 1000, seed: int = 0) -> dict:
    """Matched on (season, date, playing-time tercile, slump quintile)."""
    g = g[g["ros_pa"] >= 75].dropna(subset=["resid", "slump"]).copy()
    c = ctl.copy()
    key = ["season", "as_of"]
    c["pt"] = c.groupby(key)["ytd_pa"].transform(lambda s: pd.qcut(s.rank(method="first"), 3, labels=False) if len(s) > 2 else 0)
    c["sb"] = c.groupby(key)["slump"].transform(lambda s: pd.qcut(s.rank(method="first"), 5, labels=False) if len(s) > 4 else 0)
    g["as_of"] = g["flag_date"]
    # assign each flagged hitter to the control cell edges of its date
    out = []
    for r in g.itertuples(index=False):
        cc = c[(c["season"] == r.season) & (c["as_of"] == r.as_of)]
        if cc.empty:
            continue
        pt_edges = cc.groupby("pt")["ytd_pa"].min()
        sb_edges = cc.groupby("sb")["slump"].min()
        pt = int(pt_edges[pt_edges <= r.ytd_pa].index.max()) if (pt_edges <= r.ytd_pa).any() else 0
        sb = int(sb_edges[sb_edges <= r.slump].index.max()) if (sb_edges <= r.slump).any() else 0
        cell = cc[(cc["pt"] == pt) & (cc["sb"] == sb) & (cc["batter"] != r.batter)]
        if len(cell) < 3:
            continue
        out.append((r.batter, r.season, r.resid - np.average(cell["resid"], weights=cell["ros_pa"]), r.ros_pa))
    if not out:
        return {"n": 0}
    o = pd.DataFrame(out, columns=["batter", "season", "rel", "w"])
    rng = np.random.default_rng(seed)
    cl = pd.factorize(o["batter"].astype(str) + o["season"].astype(str))[0]
    mem = [np.flatnonzero(cl == k) for k in range(cl.max() + 1)]
    bs = []
    for _ in range(n_boot):
        i = np.concatenate([mem[k] for k in rng.integers(0, len(mem), len(mem))])
        bs.append(np.average(o["rel"].to_numpy()[i], weights=o["w"].to_numpy()[i]))
    lo, hi = np.percentile(bs, [2.5, 97.5])
    return {"n": len(o), "hitters": len(mem), "diff": np.average(o["rel"], weights=o["w"]), "ci_lo": lo, "ci_hi": hi}


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    fl = pd.concat([pd.read_csv(RESULTS / f"flags_{y}_scored.csv", parse_dates=["flag_date", "change_date"])
                    for y in SEASONS], ignore_index=True)
    ins = fl[fl["kind"] == "in-season"].copy()
    ins["slump"] = ins["ytd_xwoba"] - ins["proj"]
    first = lambda x: x.sort_values("flag_date").drop_duplicates(["batter", "season"])
    st = first(ins[ins["metric"].isin(["stance_angle", "foot_sep"])])

    # ---- 1. slump at change date vs flag date
    chg = st[["batter", "season", "change_date"]].rename(columns={"change_date": "as_of"})
    snaps_c = oc.all_snapshots(cum, prior, {y: sorted(chg.loc[chg.season == y, "as_of"].unique()) for y in SEASONS})
    snaps_c["proj"] = proj.predict(snaps_c)
    snaps_c["slump"] = snaps_c["ytd_xwoba"] - snaps_c["proj"]
    sc = chg.merge(snaps_c[["batter", "season", "as_of", "slump", "ytd_pa"]], on=["batter", "season", "as_of"])
    allc = snaps_c[snaps_c["ytd_pa"] >= 60]
    sc = sc[sc["ytd_pa"] >= 60]
    print("1. How far below projection stance changers were (season-to-date xwOBA minus projection), 60+ PA:")
    print(f"   at the change date: mean {sc['slump'].mean():+.3f}, share below projection {(sc['slump'] < 0).mean():.0%}, "
          f"share 25+ pts below {(sc['slump'] < -.025).mean():.0%}")
    print(f"   everyone else, same dates: mean {allc['slump'].mean():+.3f}, below {(allc['slump'] < 0).mean():.0%}, "
          f"25+ pts below {(allc['slump'] < -.025).mean():.0%}")
    s2 = st[st["ytd_pa"] >= 60]
    print(f"   at the flag date (~5 days later): mean {s2['slump'].mean():+.3f}, below {(s2['slump'] < 0).mean():.0%}")
    for y in SEASONS:
        a = sc[sc["season"] == y]
        print(f"     {y}: change-date mean {a['slump'].mean():+.3f}, below projection {(a['slump'] < 0).mean():.0%}")

    # ---- 2. calibration of the projection by slump, all hitters on Mondays
    snaps = pd.read_parquet(DATA / "snapshots.parquet")
    c = ev.control_pool(snaps, proj)
    c["slump"] = c["ytd_xwoba"] - c["proj"]
    c = c[c["ytd_pa"] >= 60]
    print("\n2. Projection calibration: rest-of-season residual by how far season-to-date ran from projection")
    for y in SEASONS + ["all"]:
        x = c if y == "all" else c[c["season"] == y]
        x = x.assign(q=pd.qcut(x["slump"], 5, labels=["coldest", "2", "3", "4", "hottest"]))
        tab = x.groupby("q", observed=True).apply(lambda d: np.average(d["resid"], weights=d["ros_pa"]), include_groups=False)
        m = sm.WLS(x["resid"], sm.add_constant(x["slump"]), weights=x["ros_pa"]).fit(
            cov_type="cluster", cov_kwds={"groups": x["batter"]})
        print(f"   {str(y):<5} by slump quintile (coldest..hottest): " + "  ".join(f"{v:+.3f}" for v in tab.values) +
              f"   | slope {m.params['slump']:+.3f} (p {m.pvalues['slump']:.2f})  [negative = slumpers beat projection]")

    # ---- 3. re-score with slump-matched controls
    conf = pd.read_csv(RESULTS / "followups_stance_swing_quality.csv", parse_dates=["flag_date", "change_date"])
    conf["slump"] = conf["ytd_xwoba"] - conf["proj"]
    m_, d_ = ins["metric"], ins["delta"]
    groups = {
        "feet narrowed 4.5+ in": first(ins[(m_ == "foot_sep") & (d_ < 0)]),
        "feet widened 4.5+ in": first(ins[(m_ == "foot_sep") & (d_ > 0)]),
        "opened 15+ deg": first(ins[(m_ == "stance_angle") & (d_ <= -15)]),
        "any other stance change (STANCE level)": first(ins[ins["level"] == "STANCE"]),
        "box position moved": first(ins[m_.isin(["dist_off_plate", "depth_in_box"])]),
        "bat speed up 2+ mph": first(ins[(m_ == "bat_speed") & (d_ > 0)]),
        "swing xwOBA up .010+ (3-wk read)": first(conf[conf["dq"] >= 0.010]),
    }
    dates = {y: sorted(pd.concat([g.loc[g["season"] == y, "flag_date"] for g in groups.values()]).unique()) for y in SEASONS}
    ctl = ev.control_pool(oc.all_snapshots(cum, prior, dates), proj)
    ctl["slump"] = ctl["ytd_xwoba"] - ctl["proj"]
    print("\n3. vs projection, controls matched on date + playing time + SLUMP DEPTH (first flag per hitter-season)")
    print(f"   {'group':<40} {'2024-25':>24} {'2026':>24} {'pooled':>24}   (date+PA match only, pooled)")
    rows = []
    for name, g in groups.items():
        cells = []
        for lab, sel in [("2024-25", g["season"] < 2026), ("2026", g["season"] == 2026), ("pooled", g["season"] > 0)]:
            r = compare_slump_matched(g[sel], ctl)
            cells.append(f"{r.get('diff', np.nan):+.3f} [{r.get('ci_lo', np.nan):+.3f},{r.get('ci_hi', np.nan):+.3f}]")
            rows.append(dict(group=name, seasons=lab, **r))
        base = ev.compare(g, ctl, n_boot=500)
        print(f"   {name:<40} " + " ".join(f"{x:>24}" for x in cells) + f"   {base['diff']:+.3f}")
    pd.DataFrame(rows).to_csv(RESULTS / "slump_check.csv", index=False)


if __name__ == "__main__":
    main()
