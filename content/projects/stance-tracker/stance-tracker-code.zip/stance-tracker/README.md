# Stance & swing changepoint tracker

Flags hitters whose batting stance or swing has shifted, using Savant's per-day batting stance
(stance angle, foot separation, box position) and pitch-level bat tracking. It also lists hitters
who just got hot or cold, along with any logged change behind them. Thresholds were set on 2024-25
and tested by replaying 2026 one day at a time with only the data available on each date. The
write-up is `../stance-tracker/index.md`.

## Running it in season

```
python update.py                                   # pull through yesterday, rebuild, write + print the digest
python update.py --as-of 2027-05-10                # digest for a given date
python update.py --skip-pull                       # rebuild/report from the caches only
python tracker.py --as-of 2027-05-10 --player Benge   # one hitter's change log + monthly levels
```

Nothing needs to change for a new season. The season comes from the date, and prior seasons are
whatever is in `../savant_cache`. Each run:

- pulls every new day through yesterday, using `../bat-speed-three/code/savant_swings.py` for the
  pitches and `savant_stance.py` for stance;
- re-pulls the last 3 days (`--refresh-days`), in case Savant hadn't finished posting them;
- rebuilds and refits the adjustments on prior seasons;
- writes `results/digests/digest_<date>.txt`, `results/change_log_<season>.csv`, and
  `results/stance_daily_<season>.csv` (that season's raw per-day stance values, for reference).

A weekly run takes ~10 minutes: ~5 to scrape a week of days, ~5 to rebuild. The first run of a
season pulls every day so far.

**Weekly schedule (Windows).** `run_weekly.bat` runs `update.py` and appends everything to
`results/digests/update_log.txt`. To run it every Monday at noon, after Sunday's games have posted:

```
schtasks /Create /TN "MLB stance tracker" /SC WEEKLY /D MON /ST 12:00 /TR "\"C:\Users\Liam\Documents\mlb-analytics\content\projects\changepoint-tracker\run_weekly.bat\""
```

Remove it with `schtasks /Delete /TN "MLB stance tracker" /F`. The PC has to be on and logged in
at that time; if it isn't, just run `run_weekly.bat` by hand.

**When things show up in a new season.** Offseason changes (vs the end of last season) appear from
about day 5. In-season stance and swing flags start ~3 weeks in, once there's a baseline. HOT/COLD
needs 100 PA, so it starts around late April. CONFIRM reads come 3 weeks after each stance change.

**Weekly vs daily.** Stance is checked for every day inside each run, so the change dates are
exact either way. Running weekly only means you see a flag up to a week later; the median lag from
change to flag is 5 days with daily runs.

The digest has four parts:

| Section | What it is |
|---|---|
| **SIGNAL** | change types historically followed by better-than-projected hitting (below), with a same-split "did the swing follow" table |
| **STANCE** | every other significant stance-angle / foot-separation change, logged for tracing; box-position moves on one line |
| SWING | count of swing-metric changes this week (full detail in the log) |
| **CONFIRM** | stance changes from ~3 weeks ago: change in *swing xwOBA*, i.e. what the hitter's bat speed, attack angle, attack direction, contact depth and tilt predict for xwOBA league-wide. UP = +.010 or more, which historically went with beating projection by +.016. It describes the swing profile; it doesn't grade a swing as better or worse for that hitter. |
| **HOT / COLD** | hitters whose last 100 PA just moved .060+ xwOBA from their projection, with any logged stance change from 21 days before the stretch onward |

Every flag of the season so far is written to `results/change_log_<season>.csv`.

## Levels and thresholds

Thresholds are in `thresholds.json`. The z thresholds are the 99th percentile of season-max |z|
under a no-change simulation, so at most 1% of hitter-seasons get a noise flag per metric. The
deltas are the minimum shift to log.

| Metric | Logged at | SIGNAL when | Evidence for SIGNAL (2024-26, first flag per hitter, vs matched controls) |
|---|---|---|---|
| Foot separation | 4.5 in | narrowed | **strong**: +.009 [+.005, +.014]; +.006 vs other stance changers; survives age/rookie/slump controls (p < .001) |
| Stance angle | 12° | opened 15°+ | moderate: +.015 [+.001, +.029], only 24 hitters |
| Bat speed | 2 mph | up | mixed: +.011 in 2024-25, +.002 in 2026 |
| Distance off plate / depth in box | 2 in / 3 in | never | no signal |
| Attack direction / contact depth / attack angle / tilt | 6° / 3.5 in / 4.5° / 2.5° | never | no signal |
| Offseason change, first 5 weeks vs last 30 games of last season, net of the league-wide shift (stance, box position, and swing metrics; same size thresholds) | as above | never | stance +.004, swing +.000 (2025-26); logged so e.g. Cam Smith's 2026 move 6 in deeper in the box and +2.7 mph shows up on Mar 31 / Apr 2 |

Chase and zone-swing rates are computed but never trigger: there are too few pitches per game to
catch a shift within a few weeks.

## What it found

The outcome is rest-of-season xwOBA minus the projection as of the flag date (prior-season wOBA
plus season-to-date xwOBA, regressed to league average), compared with hitters on the same day in
the same playing-time band. CIs resample hitters.

- **Most stance changes don't beat projection.** Most groups are within a few points of zero, and
  even for narrowed feet only 31% of hitters beat projection by .025+ (19% for controls).
- **Narrowed feet is the one signal that held up** in 2024-25 (+.006) and in the 2026 holdout
  (+.015). 2026 was generous to nearly every flag type, so +.006 against other stance changers is
  the cleaner number. It's the only one of 11 groups that survives a multiple-comparison correction.
- **Before/after comparisons mislead.** Widened feet look like +.009 by before/after, but those
  hitters were slumping, and against projection they come out at +.002.
- **The swing following the stance matters only if it moves toward a higher-xwOBA profile.** Following in any
  direction does nothing (+.004 vs +.004 for stance-only). Scored with a swing-quality model
  ("swing xwOBA": hitter-season xwOBA on bat speed, attack angle, attack direction, contact depth, and
  tilt; fit on 2024-25, R² .24 on 2026), stance changes whose 3-week swing xwOBA rose .010+ beat projection by
  +.016 [+.005, +.026], and 41% beat it by .025+ (controls 19%). This holds in both samples, with
  a dose-response p = .005, but it's exploratory and only 39 hitters. Most of these gains are bat
  speed; Benge's were mostly lift and pull.
- **Why not everyone narrows:** stance width itself doesn't relate to xwOBA (r = .05). Narrowers
  mostly start wide (62nd percentile), and the ones narrowing back toward last season's width did
  best (+.017). Bat speed and swing xwOBA don't explain the effect (`followups.py`).
- **Tracing works for a minority of breakouts.** Narrowed/opened changes appear before 14% of hot
  streaks, against 9% for other hitters on the same dates, and before fewer cold streaks than
  chance. A logged change doesn't make a hot streak more likely to last (+.004, n.s.). Cold
  hitters who changed stance did recover more than other cold hitters (+.011 [+.002, +.019]).
- **Offseason detection works** (it caught every hitter in MLB.com's April 2025 stance piece that I
  checked, by April 6, and with box position + swing metrics it catches Cam Smith's 2026 changes by
  March 31), but offseason changes didn't beat projection.
- **Value:** +.009 over a typical 263 remaining PA is about 2 runs. Treat it as a tiebreaker.

## 2026 replay highlights

- **Benge:** closed 12.3° on Apr 21, flagged STANCE on Apr 25. Then attack direction +7.5°,
  contact ~3 in further out front, attack angle +4.7°. He hit .349 xwOBA the rest of the way
  against a .310 projection.
- **Tatis:** flagged on Apr 1 as 29° more closed and 6 in wider than at the end of 2025. First
  SIGNAL Apr 15 (feet narrowed 8.4 in); 14 flags in all. He hit .381 against a .344 projection from
  that first SIGNAL.

## How it works

1. **Data.** `../savant_cache` holds every regular-season pitch, one file per day, from
   `../bat-speed-three/code/savant_swings.py`. `savant_stance.py` pulls Savant's batting-stance CSV one day
   at a time. The endpoint filters on `seasonStart`/`seasonEnd`/`dateStart`/`dateEnd`; `year` and
   `month` are ignored. Stance is one value per hitter per day, averaged over that day's swings and
   measured about 1 s before release; there is no per-pitch stance. Switch hitters are tracked
   separately for each side.
2. **Adjustment** (`adjust.py`, `cpd.adjust_stance`). Each swing metric is modeled within
   hitter-season against what the hitter doesn't control: location, pitch type, velo, movement,
   count, platoon, and park. Out of sample this explains 49% of attack-direction variance and 54%
   of contact-depth variance. Contact depth itself is not adjusted for. Stance box position gets a
   park × side offset, and the league seasonal drift is removed using prior seasons.
3. **Noise model** (`cpd.estimate_noise`). Each game's variance is sigma²/n + tau², fit on
   adjacent-game differences.
4. **Scan** (`cpd.best_split`, `tracker.run_online`). The tracker finds the best single split since
   the metric's last accepted change and flags it when it clears both z and delta; the change date
   then starts a new regime. `offseason.py` runs the first-weeks comparison against last season.
5. **Evaluation** (`replay_eval.py`, `robustness.py`, `attribution.py`, `sweep.py`).

## Files

| | |
|---|---|
| `update.py` | in-season entry point |
| `tracker.py` | scan, levels, digest, `--player`, `--replay SEASON` |
| `offseason.py` | first-weeks vs last-season check, league-shift corrected (`scan_shifted`; `main_extended()` calibrates and scores it) |
| `savant_stance.py` | per-day stance pull (cache in `stance_cache/`) |
| `build_data.py`, `adjust.py`, `cpd.py` | swing/PA/decision tables, adjustment, game table, noise model, scan |
| `outcomes.py`, `evaluate.py` | projection, persistence, same-split shifts, matched-control comparison |
| `analysis.py`, `study_stance.py`, `sweep.py` | 2024-25 calibration and threshold study |
| `replay_eval.py` | scores replays (`--seasons 2026`, or `2024 2025 2026` pooled) |
| `robustness.py` | controlled regression, naive before/after, contrasts |
| `attribution.py` | hot/cold streak tracing vs same-date baseline |
| `followups.py` | swing-quality model (writes `data/swing_quality.pkl` for CONFIRM), the narrowing deep-dive, what moves with each change type |
| `figures.py` | the two charts |
| `results/` | `flags_<season>.csv`, `flags_<season>_scored.csv`, `groups_*.csv`, `robustness*.csv`, `attribution_summary.csv`, `streaks.csv`, `offseason_flags.csv`, `threshold_sweep.csv` |

For a new season, add the finished season to the history lists (`HIST` in `analysis.py`, the
default `seasons_hist` arguments in `cpd.py`). `update.py` already trains the adjustments on every
prior season. Keeping the 2024-25 thresholds is fine; recalibrating is optional.

`data/` (~230 MB) and `stance_cache/` are regenerated by the scripts and are listed in this
folder's `.gitignore`. Hugo copies files under `content/` into the built site, so keep them out of
any commit.
