#!/usr/bin/env python3
"""
update.py  --  one command for in-season use

    python update.py                      # pull through yesterday, rebuild, write + print the weekly digest
    python update.py --as-of 2027-05-10   # report for a specific date
    python update.py --skip-pull          # rebuild/report from what is already cached

Steps: pitch-level pull (../bat-speed-three/code/savant_swings.py, daily cache in
../savant_cache) -> stance pull (savant_stance.py) -> build_data.py -> adjust.py
(models trained on prior seasons only) -> park-adjusted stance + game table ->
tracker.py --as-of. The digest is also saved to results/digests/digest_<date>.txt.

Both scrapers cache each finished day and never refetch it, so the last few days are
cleared and pulled again on every run (--refresh-days, default 3). That picks up games
and bat tracking that Savant hadn't finished posting the last time.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECTS = HERE.parent
PITCH_CACHE = PROJECTS / "savant_cache"
STANCE_CACHE = HERE / "stance_cache"
SCRAPER = next((p for p in [PROJECTS / "bat-speed-three" / "code" / "savant_swings.py",
                            PROJECTS / "bat-speed-three" / "savant_swings.py"] if p.exists()), None)


def run(cmd: list[str], cwd: Path) -> None:
    print(f"\n$ {' '.join(cmd)}", flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def recent_cache_files(as_of: date, days: int) -> list[Path]:
    """Cached files for the last `days` days before as_of (pitch-level and stance)."""
    out = []
    for k in range(1, days + 1):
        d = as_of - timedelta(days=k)
        out += [PITCH_CACHE / str(d.year) / f"{d.isoformat()}.csv.gz",
                PITCH_CACHE / str(d.year) / f"{d.isoformat()}.empty",
                STANCE_CACHE / str(d.year) / f"{d.isoformat()}.csv"]
    return [p for p in out if p.exists()]


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--as-of", default=date.today().isoformat())
    p.add_argument("--skip-pull", action="store_true")
    p.add_argument("--refresh-days", type=int, default=3,
                   help="clear and re-pull this many most recent days (default 3)")
    args = p.parse_args()
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    as_of = date.fromisoformat(args.as_of)
    season = as_of.year
    py = sys.executable

    if not args.skip_pull:
        if SCRAPER is None:
            sys.exit("can't find savant_swings.py under ../bat-speed-three/")
        stale = recent_cache_files(as_of, args.refresh_days)
        for f in stale:
            f.unlink()
        if stale:
            print(f"cleared {len(stale)} cached file(s) from the last {args.refresh_days} days to re-pull")
        run([py, str(SCRAPER), "--seasons", str(season)], PROJECTS)
        run([py, "savant_stance.py", "--seasons", str(season), "--no-build"], HERE)
    run([py, "savant_stance.py", "--build-only"], HERE)

    seasons = sorted(int(d.name) for d in PITCH_CACHE.iterdir() if d.name.isdigit())
    run([py, "build_data.py", "--seasons", *map(str, seasons)], HERE)
    run([py, "adjust.py", "--target-seasons", *map(str, seasons)], HERE)

    sys.path.insert(0, str(HERE))
    import cpd
    prior = [s for s in seasons if s < season]
    cpd.adjust_stance(prior)
    cpd.build_game_table(prior).to_parquet(HERE / "data" / "games.parquet", index=False)

    export_stance_csv(season)

    print(f"\n$ tracker.py --as-of {args.as_of}", flush=True)
    res = subprocess.run([py, "tracker.py", "--as-of", args.as_of], cwd=HERE, check=True,
                         capture_output=True, text=True, encoding="utf-8")
    out_dir = HERE / "results" / "digests"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"digest_{args.as_of}.txt"
    out.write_text(res.stdout, encoding="utf-8")       # save before printing, in case the console can't encode a name
    print(res.stdout)
    print(f"digest saved to {out}")


def export_stance_csv(season: int) -> None:
    """Readable copy of this season's per-day Savant stance values (raw, not park-adjusted)."""
    import pandas as pd
    st = pd.read_parquet(HERE / "data" / "stance_daily.parquet")
    st = st[st["season"] == season]
    sw = pd.read_parquet(HERE / "data" / "swings.parquet", columns=["batter", "game_date", "stand", "home_team"])
    n = (sw.groupby(["batter", "game_date", "stand"]).agg(swings=("home_team", "size"), park=("home_team", "first"))
           .reset_index().rename(columns={"stand": "bat_side"}))
    out = st.merge(n, on=["batter", "game_date", "bat_side"], how="left")
    cols = ["game_date", "batter", "name", "bat_side", "park", "swings", "stance_angle", "foot_sep",
            "dist_off_plate", "depth_in_box", "int_y_vs_batter", "int_y_vs_plate"]
    out = out[cols].sort_values(["name", "bat_side", "game_date"])
    out["game_date"] = out["game_date"].dt.strftime("%Y-%m-%d")
    out = out.round(2)
    out.to_csv(HERE / "results" / f"stance_daily_{season}.csv", index=False, encoding="utf-8-sig")


if __name__ == "__main__":
    main()
