#!/usr/bin/env python3
"""
sweep.py  --  magnitude-threshold sweep on 2024-25 (tracker rerun at each candidate)

For each metric and candidate delta, replays 2024-25 with z from the null
calibration and that delta, then reports how often it fires and what happened
next (persistence; rest-of-season xwOBA vs projection from the flag date, which
is what you could act on, and from the change date, which is the "did the
change come with better hitting at all" question).

Writes results/threshold_sweep.csv
"""

from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

import cpd
import evaluate as ev
import outcomes as oc
import tracker

HERE = Path(__file__).resolve().parent
DATA, RESULTS = HERE / "data", HERE / "results"
HIST = [2024, 2025]

CANDIDATES = {
    "stance_angle": [0, 6, 8, 10, 12, 15],
    "foot_sep": [0, 2.5, 3.5, 4.5, 6],
    "dist_off_plate": [0, 1.5, 2, 2.5],
    "depth_in_box": [0, 2, 3, 4],
    "ad_pull": [0, 5, 7, 9],
    "depth": [0, 3, 4, 5],
    "ad_at_depth": [0, 2.5, 3.5, 4.5],
    "bat_speed": [0, 1.5, 2, 2.5, 3],
    "attack_angle": [0, 4, 5, 6],
    "tilt": [0, 2, 2.5, 3],
}


def week_start(d: pd.Series) -> pd.Series:
    return d - pd.to_timedelta(d.dt.weekday, unit="D")


def main() -> None:
    cal = json.load(open(RESULTS / "calibration_stage1.json"))
    noise = {m: cpd.Noise(**v) for m, v in cal["noise"].items()}
    z = cal["z"]
    g = pd.read_parquet(DATA / "games.parquet")
    pa = oc.load_pa()
    cum, prior = oc.daily_cum(pa), oc.load_prior()
    proj = pickle.load(open(DATA / "projection.pkl", "rb"))
    snaps = pd.read_parquet(DATA / "snapshots.parquet")
    n_weeks = sum(len(tracker.mondays(g, s)) for s in HIST)
    n_reg = (g[g["season"].isin(HIST)].groupby(["batter", "stand", "season"])["n_sw"].sum() >= 300).sum()

    # controls at every Monday + at every week start (for change-date outcomes)
    weeks = {s: sorted(set(tracker.mondays(g, s)) |
                       set(week_start(g.loc[g["season"] == s, "game_date"]).unique())) for s in HIST}
    snaps_w = oc.all_snapshots(cum, prior, weeks)
    ctl = ev.control_pool(snaps_w, proj)

    rows = []
    for m, deltas in CANDIDATES.items():
        for d in deltas:
            fl = pd.concat([tracker.run_online(g, s, [m], noise, {m: z[m]}, {m: d}) for s in HIST])
            if fl.empty:
                continue
            fl = ev.persistence(fl, g, noise)
            a = ev.attach_outcomes(fl, cum, prior, proj)
            r_flag = ev.compare(a, ctl)
            fc = fl.copy()
            fc["flag_date"] = week_start(fc["change_date"])
            r_chg = ev.compare(ev.attach_outcomes(fc, cum, prior, proj), ctl)
            row = dict(metric=m, delta=d, z=z[m], flags=len(fl), hitters=fl["batter"].nunique(),
                       per_week=len(fl) / n_weeks, per_regular_season=len(fl) / n_reg,
                       lag_days_med=(fl["flag_date"] - fl["change_date"]).dt.days.median(),
                       held_share=(fl["retained"] >= 0.5).mean())
            row.update({f"flag_{k}": v for k, v in r_flag.items() if k != "mean_resid"})
            row.update({f"chg_{k}": v for k, v in r_chg.items() if k in ("n", "diff", "ci_lo", "ci_hi", "share_good", "control_share_good", "share_bad")})
            rows.append(row)
            print(f"{m:<14} d>={d:<5} flags={len(fl):>5} /wk={row['per_week']:5.1f}  held={row['held_share']:.2f}  "
                  f"from flag: {r_flag.get('diff', np.nan):+.3f} [{r_flag.get('ci_lo', np.nan):+.3f},{r_flag.get('ci_hi', np.nan):+.3f}] "
                  f"good {r_flag.get('share_good', np.nan):.2f} vs {r_flag.get('control_share_good', np.nan):.2f}   "
                  f"from change: {r_chg.get('diff', np.nan):+.3f} [{r_chg.get('ci_lo', np.nan):+.3f},{r_chg.get('ci_hi', np.nan):+.3f}]",
                  flush=True)
    pd.DataFrame(rows).to_csv(RESULTS / "threshold_sweep.csv", index=False)


if __name__ == "__main__":
    main()
