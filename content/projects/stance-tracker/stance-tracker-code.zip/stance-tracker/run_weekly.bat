@echo off
REM Weekly stance/swing tracker run: pulls through yesterday, rebuilds, writes
REM results\digests\digest_<date>.txt. Full output is appended to results\digests\update_log.txt.
cd /d "%~dp0"
if not exist results\digests mkdir results\digests
set PY=C:\Users\Liam\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\python.exe
echo ===== %date% %time% ===== >> results\digests\update_log.txt
"%PY%" update.py >> results\digests\update_log.txt 2>&1
