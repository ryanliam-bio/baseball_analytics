#!/usr/bin/env python3
"""
savant_stance.py  --  per-game batting stance pull for the changepoint tracker

Pulls Savant's batting stance CSV (stance angle, foot separation, depth in box,
distance off plate, intercept vs batter/plate) one day at a time, so every
hitter gets one stance reading per game day. Weekly or monthly values can be
rebuilt from these by weighting each day by that hitter's tracked swings.

Run:
    python savant_stance.py                         # 2024, 2025, 2026 game days
    python savant_stance.py --seasons 2026          # one season
    python savant_stance.py --start 2027-04-01 --end 2027-04-07   # in-season update
    python savant_stance.py --build-only            # rebuild parquet from cache

Safe to stop and rerun; finished days are cached in ./stance_cache.
Game days are taken from ../savant_cache (the pitch-level pull) when available,
otherwise every day in the requested window is tried.

Output: ./data/stance_daily.parquet
"""

from __future__ import annotations

import argparse
import io
import random
import sys
import time
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import requests

HERE = Path(__file__).resolve().parent
STANCE_CSV = "https://baseballsavant.mlb.com/visuals/batting-stance"
SEASON_WINDOW = ("03-15", "10-05")
EXPECTED_HEADER = ["id", "name", "bat_side", "side", "avg_batter_y_position",
                   "avg_batter_x_position", "avg_foot_sep", "avg_stance_angle",
                   "avg_intercept_y_vs_batter", "avg_intercept_y_vs_plate"]


def build_params(day: date) -> dict:
    # `year`/`month` are ignored by this endpoint; seasonStart/End + dateStart/End are what filter.
    return {
        "csv": "true", "type": "batter", "gameType": "Regular",
        "minSwings": "1", "minGroupSwings": "1",
        "seasonStart": str(day.year), "seasonEnd": str(day.year),
        "dateStart": day.isoformat(), "dateEnd": day.isoformat(),
    }


def game_days(seasons, start, end, pitch_cache: Path) -> list[date]:
    yesterday = date.today() - timedelta(days=1)
    days = []
    for yr in seasons:
        d0 = date.fromisoformat(start) if start else date.fromisoformat(f"{yr}-{SEASON_WINDOW[0]}")
        d1 = date.fromisoformat(end) if end else date.fromisoformat(f"{yr}-{SEASON_WINDOW[1]}")
        d1 = min(d1, yesterday)
        known = {date.fromisoformat(f.name[:10]) for f in (pitch_cache / str(yr)).glob("*.csv.gz")}
        known_empty = {date.fromisoformat(f.name[:10]) for f in (pitch_cache / str(yr)).glob("*.empty")}
        d = d0
        while d <= d1:
            if d.year == yr and (d in known or d not in known_empty):
                days.append(d)
            d += timedelta(days=1)
    return days


def fetch_day(day: date, session: requests.Session, cache_dir: Path, attempts: int = 6) -> str:
    out = cache_dir / str(day.year) / f"{day.isoformat()}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    last = ""
    for attempt in range(1, attempts + 1):
        time.sleep(random.uniform(1.0, 2.5))
        try:
            r = session.get(STANCE_CSV, params=build_params(day), timeout=(20, 120))
            if r.status_code != 200:
                raise ValueError(f"HTTP {r.status_code}")
            text = r.content.decode("utf-8-sig", errors="replace")
            header = [h.strip('"') for h in text.split("\n", 1)[0].strip().split(",")]
            if header[:len(EXPECTED_HEADER)] != EXPECTED_HEADER:
                raise ValueError(f"unexpected header {header[:4]}")
            tmp = out.with_suffix(".tmp")
            tmp.write_text(text, encoding="utf-8")
            tmp.replace(out)  # atomic, so a cached day is always complete
            return f"ok {text.count(chr(10)) - 1} rows"
        except (requests.RequestException, ValueError) as exc:
            last = str(exc)[:120]
            time.sleep(min(240, 10 * 2 ** (attempt - 1)))
    return f"FAILED ({last})"


def build(cache_dir: Path, out_path: Path) -> pd.DataFrame:
    frames = []
    for f in sorted(cache_dir.glob("*/*.csv")):
        df = pd.read_csv(f)
        if df.empty:
            continue
        df["game_date"] = pd.Timestamp(f.name[:10])
        frames.append(df)
    st = pd.concat(frames, ignore_index=True).rename(columns={
        "id": "batter", "avg_batter_y_position": "depth_in_box",
        "avg_batter_x_position": "dist_off_plate", "avg_foot_sep": "foot_sep",
        "avg_stance_angle": "stance_angle", "avg_intercept_y_vs_batter": "int_y_vs_batter",
        "avg_intercept_y_vs_plate": "int_y_vs_plate"})
    st["season"] = st["game_date"].dt.year
    st = st.drop(columns=["side"])
    out_path.parent.mkdir(parents=True, exist_ok=True)
    st.to_parquet(out_path, index=False)
    print(f"stance_daily: {len(st):,} hitter-days, {st['batter'].nunique():,} hitters -> {out_path}")
    return st


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seasons", type=int, nargs="+", default=[2024, 2025, 2026])
    p.add_argument("--start")
    p.add_argument("--end")
    p.add_argument("--cache-dir", type=Path, default=HERE / "stance_cache")
    p.add_argument("--pitch-cache", type=Path, default=HERE.parent / "savant_cache")
    p.add_argument("--out", type=Path, default=HERE / "data" / "stance_daily.parquet")
    p.add_argument("--build-only", action="store_true")
    p.add_argument("--no-build", action="store_true", help="fetch only (for parallel per-season runs)")
    p.add_argument("--refresh", action="store_true", help="refetch days already cached")
    args = p.parse_args()

    if not args.build_only:
        days = game_days(args.seasons, args.start, args.end, args.pitch_cache)
        todo = [d for d in days if args.refresh or
                not (args.cache_dir / str(d.year) / f"{d.isoformat()}.csv").exists()]
        print(f"{len(days)} days in range, {len(todo)} to fetch", flush=True)
        session = requests.Session()
        session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"})
        failed = []
        for i, d in enumerate(todo, 1):
            status = fetch_day(d, session, args.cache_dir)
            print(f"[{i:>4}/{len(todo)}] {d}  {status}", flush=True)
            if status.startswith("FAILED"):
                failed.append(d)
        if failed:
            print(f"{len(failed)} days failed; rerun to retry: {[str(d) for d in failed]}")
    if not args.no_build:
        build(args.cache_dir, args.out)


if __name__ == "__main__":
    sys.exit(main())
